package views;

import dao.USER_TBL_DAO;
import vo.USER_TBL_VO;

public class Test {
	public static void main(String[] args) {
		USER_TBL_DAO dao = new USER_TBL_DAO();
		USER_TBL_VO vo = new USER_TBL_VO();
		
		dao.findPw("hds", "본인 핸드폰 번호");
		
		
//		System.out.println(dao.findId("01012341234", "1111"));
		
//		if(dao.login("hds", "1234")) {
//			System.out.println("로그인 성공");
//			System.out.println(USER_TBL_DAO.session_id + "님 환영합니다.");
//			
//			if(dao.changePw("1234", "1111")) {
//				System.out.println("비밀번호 변경 다시 로그인해주세요.");
//				dao.logout();
//				
//				if(dao.login("hds", "1111")) {
//					System.out.println("로그인 성공");
//					System.out.println(USER_TBL_DAO.session_id + "님 환영합니다.");
//				}else {
//					System.out.println("로그인 실패");
//				}
//			}else {
//				System.out.println("비밀번호가 잘못되었습니다./");
//			}
			
//			if(dao.delete("1234")) {
//				System.out.println("회원탈퇴 성공");
//				dao.logout();
//			}
			
//			if(dao.logout()) {
//				System.out.println("로그아웃 성공");
//			}else {
//				System.out.println("로그인 후 이용 가능합니다.");
//			}
			
//		}else {
//			System.out.println("로그인 실패");
//		}
		
//		vo.setAge(10);
//		vo.setId("hds1");
//		vo.setName("한동석");
//		vo.setPhoneNumber("01012341234");
//		vo.setPw("1234");
//		
//		if(dao.join(vo)) {
//			System.out.println("회원가입 성공");
//		}else {
//			System.out.println("회원가입 실패");
//		}
	}
}
