package com.koreait.app.board.vo;

public class FilesVO {
	private String fileName;
	private int boardNum;
	
	public FilesVO() {;}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public int getBoardNum() {
		return boardNum;
	}

	public void setBoardNum(int boardNum) {
		this.boardNum = boardNum;
	}
}
