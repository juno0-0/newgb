package com.koreait.carapp;

class Car {
    private final int KEY = 5;

    private String brand;
    private String color;
    private int price;
    private String pw = encrypt("0000");

    private int policeCnt;
    private boolean isOn;

    public Car(){;}

    public Car(String brand, String color, int price) {
        this.brand = brand;
        this.color = color;
        this.price = price;
    }

    public Car(String brand, String color, int price, String pw) {
        this.brand = brand;
        this.color = color;
        this.price = price;
        this.pw = encrypt(pw);
    }

    //암호화
    public String encrypt(String pw){
        String en_pw = "";
        for (int i=0; i<pw.length(); i++){
            en_pw += (char)pw.charAt(i) * KEY;
        }
        return en_pw;
    }

    public boolean engineStart(String pw){
        if(!isOn){
            if(this.pw.equals(encrypt(pw))){
                policeCnt = 0;
                isOn = true;
                return true;
            }
            policeCnt++;
        }
        return false;
    }

    public boolean engineStop(){
        if(isOn){
            isOn = false;
            return true;
        }
        return false;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    public int getPoliceCnt() {
        return policeCnt;
    }

    public void setPoliceCnt(int policeCnt) {
        this.policeCnt = policeCnt;
    }

    public boolean isOn() {
        return isOn;
    }

    public void setOn(boolean on) {
        isOn = on;
    }
}
