package com.koreait.carapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

public class MainActivity extends AppCompatActivity {
    ImageView main_img, start_img, stop_img, police_img;
    Car ferrari = new Car("Ferrari", "Red", 35000, "1234");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void runGif(int id, int img){
        ImageView imgGif = (ImageView)findViewById(id);
        Glide.with(this)
                .asGif()
                .load(img)
                .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                .into(imgGif);
    }

    public void onClick(View view){
        EditText pw_input = (EditText)findViewById(R.id.pw);

        main_img = findViewById(R.id.main);
        start_img = findViewById(R.id.engineStart);
        stop_img = findViewById(R.id.engineStop);
        police_img = findViewById(R.id.police);

        switch(view.getId()){
            case R.id.startBtn:
                String pw = pw_input.getText().toString();
                if(pw.length() == 0){
                    Toast.makeText(this, "비밀번호를 입력해주세요", Toast.LENGTH_SHORT).show();
                    break;
                }

                if(ferrari.engineStart(pw)){
                    pw_input.setVisibility(View.INVISIBLE);
                    main_img.setVisibility(View.INVISIBLE);
                    start_img.setVisibility(View.VISIBLE);
                    stop_img.setVisibility(View.INVISIBLE);
                    police_img.setVisibility(View.INVISIBLE);
                    runGif(R.id.engineStart, R.raw.engine_start);
                }else{
                    if(ferrari.getPoliceCnt() == 3){
                        Toast.makeText(this, "경찰 출동!", Toast.LENGTH_SHORT).show();
                        pw_input.setVisibility(View.INVISIBLE);
                        main_img.setVisibility(View.INVISIBLE);
                        start_img.setVisibility(View.INVISIBLE);
                        stop_img.setVisibility(View.INVISIBLE);
                        police_img.setVisibility(View.VISIBLE);

                        ((Button)findViewById(R.id.startBtn)).setVisibility(View.GONE);
                        ((Button)findViewById(R.id.stopBtn)).setVisibility(View.GONE);
                    }else if(ferrari.getPoliceCnt() > 0){
                        Toast.makeText(this, "비밀번호 오류 " + ferrari.getPoliceCnt() + "회" , Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(this, "이미 시동이 켜져있습니다." , Toast.LENGTH_SHORT).show();
                    }
                }
                break;
            case R.id.stopBtn:
                if(ferrari.engineStop()){
                    pw_input.setVisibility(View.VISIBLE);
                    pw_input.setText(null);
                    main_img.setVisibility(View.INVISIBLE);
                    start_img.setVisibility(View.INVISIBLE);
                    stop_img.setVisibility(View.VISIBLE);
                    police_img.setVisibility(View.INVISIBLE);
                    runGif(R.id.engineStop, R.raw.engine_stop);
                }else{
                    Toast.makeText(this, "이미 시동이 꺼져있습니다." , Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.exit:
                this.finish();
                break;
        }
    }
}

























