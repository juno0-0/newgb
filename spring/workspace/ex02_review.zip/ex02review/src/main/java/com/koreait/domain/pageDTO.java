package com.koreait.domain;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class pageDTO {
	private int startPage;
	private int endPage;
	private int realEnd;
	private boolean prev, next;
	private int total;
	private Criteria cri;
	
	public pageDTO(Criteria cri, int total) {
		this.cri = cri;
		this.total = total;
		
		this.endPage = (int)(Math.ceil((cri.getPageNum() / 10.0)) * cri.getAmount());
		this.startPage = endPage - 9;
		
		this.realEnd = (int)(Math.ceil((this.total * 1.0))) / cri.getAmount();
		if(this.endPage > this.realEnd) {
			this.endPage = this.realEnd;
		}
		
		this.prev = startPage > 1;
		this.next = this.endPage < this.realEnd;
	}
}
