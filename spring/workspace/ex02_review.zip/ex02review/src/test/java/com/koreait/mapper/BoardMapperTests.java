package com.koreait.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.koreait.domain.BoardVO;
import com.koreait.domain.Criteria;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardMapperTests {
	@Setter(onMethod_ = @Autowired)
	private BoardMapper mapper;

	//getListWithPaging
	@Test
	public void testGetListWithPaging() {
		mapper.getListWithPaging(new Criteria()).forEach(board -> log.info(board));
	}
	
//	//getTotal
//	@Test
//	public void testGetTotal() {
//		log.info(mapper.getTotal());
//	}
	
//	//insertSelectKey_bno
//	@Test
//	public void insertSelectKey_bno() {
//		BoardVO board = new BoardVO();
//		board.setTitle("테스트 중입니다~");
//		board.setContent("내용을 넣겠습니다.");
//		board.setWriter("이지은");
//		log.info("COUNT : " + mapper.insertSelectKey_bno(board));
//	}
	
//	//delete
//	@Test
//	public void testDelete() {
//		log.info("DELETE COUNT : "+mapper.delete(4194383L));
//	}
	
//	//update
//	@Test
//	public void testUpdate() {
//		BoardVO board = mapper.read(4194383L);
//		board.setTitle("수정 테스트 제목 ~");
//		board.setContent("수정 테스트 내용~");
//		log.info("UPDATE COUNT : "+mapper.update(board));
//	}
	
//	//select
//	@Test
//	public void testGetList() {
//		mapper.getList().forEach(board -> log.info(board));
//	}
	
//	//one select
//	@Test
//	public void testRead() {
//		log.info(mapper.read(4194384L));
//	}
	
//	//insert
//	@Test
//	public void testInsert() {
//		BoardVO board = new BoardVO();
//		board.setTitle("등록 테스트 제목");
//		board.setContent("등록 테스트 내용");
//		board.setWriter("이지은");
//		log.info("INSERT COUNT : "+mapper.insert(board));
//	}
	
	// 처음 테스트
//	@Test
//	public void test() {
//		log.info(mapper);
//	}
}
