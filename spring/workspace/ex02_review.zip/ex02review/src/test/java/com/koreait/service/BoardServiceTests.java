package com.koreait.service;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.koreait.domain.BoardVO;
import com.koreait.domain.Criteria;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardServiceTests {
	@Setter(onMethod_ = @Autowired)
	private BoardService service;

	@Test
	public void testRemove() {
		log.info("REMOVE RESULT : "+service.remove(4194385L));
		log.info("TOTAL : "+service.getTotal(new Criteria(1, 10, "W", "이지은")));
	}
	
//	@Test
//	public void testModify() {
//		BoardVO board = service.get(4194385L);
//		board.setTitle("수정 테스트~");
//		board.setContent("수정 테스트~");
//		log.info("MODIFY RESULT : "+service.modify(board));
//	}
	
//	@Test
//	public void testGetListWithPaging() {
//		service.getList(new Criteria(2, 20)).forEach(board -> log.info(board));
//	}
	
//	@Test
//	public void testGet() {
//		log.info(service.get(4194385L));
//	}
	
//	@Test
//	public void testRegister() {
//		BoardVO board = new BoardVO();
//		board.setTitle("테스트!");
//		board.setContent("테스트내용!");
//		board.setWriter("아이유!");
//		service.register(board);
//	}
	
	
}
