package com.koreait.mapper;

import java.util.List;
import java.util.stream.IntStream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.koreait.domain.BoardVO;
import com.koreait.domain.Criteria;
import com.koreait.domain.ReplyVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyMapperTests {
	@Setter(onMethod_ = @Autowired)
	private ReplyMapper mapper;
	
	@Setter(onMethod_ = @Autowired)
	private BoardMapper board;
	
	Long[] arBno = {4194389L, 4194388L, 4194387L, 4194386L, 4194384L};
	
	@Test
	public void testUpdate() {
		ReplyVO reply = mapper.read(25L);
		reply.setReply("수정수정수정!");
		mapper.update(reply);
		log.info(mapper.read(25L));
	}
	
//	@Test
//	public void testDelete() {
//		mapper.delete(21L);
//		mapper.getListWithPaging(arBno[0]).forEach(reply -> log.info(reply));
//	}
	
//	@Test
//	public void testGetListWithPaging() {
//		mapper.getListWithPaging(arBno[0]).forEach(reply -> log.info(reply));
//	}
	
//	@Test
//	public void testRead() {
//		log.info(mapper.read(21L));
//	}
	
//	@Test
//	public void testInsert() {
//		List<BoardVO> boards = board.getListWithPaging(new Criteria(1, 5));
//		IntStream.rangeClosed(1, 10).forEach(reply -> {
//			ReplyVO r = new ReplyVO();
//			r.setBno(boards.get(reply % 5).getBno());
//			r.setReply("테스트댓글"+reply);
//			r.setReplyer("테스트작성자"+reply);
//			mapper.insert(r);
//		});
//	}
	
//	@Test
//	public void test() {
//		log.info(mapper);
//	}
}
