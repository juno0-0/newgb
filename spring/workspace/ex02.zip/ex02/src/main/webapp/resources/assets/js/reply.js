/**
 * Javascript의 모듈화
 * 
 * 함수들을 하나의 모듈처럼 부품으로 구성하는 것을 의미한다.
 * 화면 내에서 Javascript 처리를 하다 보면 이벤트 처리와 DOM, Ajax 처리 등
 * 복잡하게 섞여서 유지보수가 힘들다. 따라서 Javascript를 하나의 모듈처럼 구성하여
 * 사용한다.
 *  
 */

console.log("Reply Module...........");

//선언하자마자 사용하겠다.
var replyService = (function(){
	
	//댓글 추가
	//필요하면 전달하고 필요하지 않으면 전달하지 않아도 되지만 전달할 경우 순서는 꼭 지키자
	function add(reply, callback, error){
		//자바스크립트는 매개변수를 10개를 써도 1개만 전달된다.
		// callback과 error는 함수를 받을 애들
		console.log("add reply...............");
		
		$.ajax({
			type: "post",
			url: "/replies/new",
			data: JSON.stringify(reply),
			contentType: "application/json; charset=utf-8",
			success: function(result){
				if(callback){
					callback(result);
				}
			},
			error: function(xhr, status, er){
				if(error){
					error(er);
				}
			}
		});
	}
	
	//댓글 목록
	//명칭은 자유롭게 해도 되지만 가독성 있게 하기
	function getList(param, callback, error){
		var bno = param.bno;
		var page = param.page || 1;
		//$.getJSON("/replies/pages/"+bno+"/"+page, function(){
		//이렇게만 쓸 경우 xml로 나오기 때문에 마지막에 .json을 추가해준다.
		$.getJSON("/replies/pages/"+bno+"/"+page+".json", 
			function(data){
				if(callback){callback(data.replyCnt, data.list);}
			//getJSON의 error는 뒤에 .fail();
		}).fail(function(xhr, status, err){
			if(error){error(err);}
		});
	}
	
	//댓글 삭제
	function remove(rno, callback, error){
		var rno = rno;
		$.ajax({
			type: "delete",
			url: "/replies/"+rno,
			success: function(result){
				if(callback){callback(result);}
			},
			error: function(xhr, status, er){
				if(error){error(er);}
			}
		});
	}
	
	//댓글 수정
	function modify(replyVO, callback, error){
		var rno = replyVO.rno;
		$.ajax({
			type: "put",
			//rno은 reply의 일부이기 때문에 따로 꺼내서 쓰는 것
			url: "/replies/"+rno,
			data: JSON.stringify(replyVO),
			contentType: "application/json; charset=utf-8",
			success: function(result){
				if(callback){callback(result);}
			},
			error: function(xhr, status, er){
				if(error){error(er);}
			}
		});
	}
	
	function get(rno, callback, error){
		//$.getJSON == $.get
		$.get("/replies/"+rno+".json", function(result){
			if(callback){callback(result);}
		}).fail(function(xhr, status, err){
			if(error){error(err)}
		});
	}
	
	/*return {name : "AAAA"};*/
	return {add : add,
			getList : getList,
			remove : remove,
			modify : modify,
			get : get}
})();