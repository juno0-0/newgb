/**
 * 
 */

console.log("Reply Module...........");

var replyService = (function(){
	function add(reply, callback, error){
		$.ajax({
			type: "post",
			url: "/replies/new",
			data: JSON.stringify(reply),
			contentType: "application/json; charset=utf-8",
			success: function(result){
				if(callback){callback(result);}
			},
			error: function(xhr, status, err){
				if(error){error(err);}
			}
		});
		
		function get(rno, callback, error){
			$.get("/replies/"+rno+".json", function(data){
				if(callback){callback(data);}
			}).fail(function(xhr, status, err){
				if(error){error(err);}
			});
		}
		
		function getList(reply, callback, error){
			$.getJSON("/replies/pages/"+reply.rno+"/"+reply.page+".json", function(data){
				if(callback){callback(data.replyCnt, data.list);}
			}).fail(function(xhr, status, err){
				if(error){error(err);}
			});
		}
		
		function remove(rno, callback, error){
			$.ajax({
				type: "delete",
				url: "/replies/"+rno,
				success: function(result){
					if(callback){callback(result);}
				},
				error: function(xhr, status, err){
					if(error){error(err);}
				}
			});
		}
		
		function modify(reply, callback, error){
			$.ajax({
				type: "put",
				url: "/replies/"+reply.rno,
				data: JSON.stringify(reply),
				contentType: "application/json; charset=utf-8",
				success: function(result){
					if(callback){callback(result);}
				},
				error: function(xhr, status, err){
					if(error){error(err);}
				}
			});
		}
		
		return {add: add,
				get: get,
				getList: getList,
				remove: remove,
				modify: modify}
	}
})();

































var replyService = (function(){
	
	function add(reply, callback, error){
		$.ajax({
			type: "post",
			url: "/replies/new",
			data: JSON.stringify(reply),
			contentType: "application/json; charset=utf-8",
			success: function(result){
				if(callback){callback(result);}
			},
			error: function(xhr, status, err){
				if(error){error(err);}
			}
		});
	}
	
	function get(rno, callback, error){
		$.get("/replies/"+rno+".json",function(data){
			if(callback){callback(data);}
		}).fail(function(xhr, status, err){
			if(error){error(err);}
		});
	}
	
	function getList(reply, callback, error){
		var bno = reply.bno;
		var page = reply.page || 1;
		$.get("/replies/pages/"+bno+"/"+page+".json", function(data){
			//getList 컨트롤러에서는 댓글 목록과 댓글 전체 개수를 응답해준다.
			//따로 전달받지 않고 ReplyPageDTO객체로 한 번에 전달 받는다.
			if(callback){callback(data.replyCnt, data.list);}//callback함수에 전체 개수와 목록을 따로 전달해준다.
		}).fail(function(xhr, status, err){
			if(error){error(err);}
		});
	}
	
	function remove(rno, callback, error){
		$.ajax({
			type: "delete",
			url: "/replies/"+rno,
			success: function(result){
				if(callback){callback(result);}
			},
			error: function(xhr, status, err){
				if(error){error(err);}
			}
		});
	}
	
	function modify(reply, callback, error){
		$.ajax({
			type: "put",
			url: "/replies/"+reply.rno,
			data: JSON.stringify(reply),
			contentType: "application/json; charset=utf-8",
			success: function(result){
				if(callback){callback(result);}
			},
			error: function(xhr, status, err){
				if(error){error(err);}
			}
		});
	}
	return {add: add,
			get: get,
			getList: getList,
			remove: remove,
			modify: modify}
})();