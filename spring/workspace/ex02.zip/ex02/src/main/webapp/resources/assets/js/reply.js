/**
 * 
 */

console.log("Reply Module...........");

var replyService = (function(){
	function add(reply, callback, error){
		$.ajax({
			type: "post",
			url: "/replies/new",
			data: JSON.stringify(reply),
			contentType: "application/json; charset=utf-8",
			success: function(result){
				if(callback){callback(result);}
			},
			error: function(xhr, status, err){
				if(error){error(err);}
			}
		});
		
		function get(rno, callback, error){
			$.get("/replies/"+rno+".json", function(data){
				if(callback){callback(data);}
			}).fail(function(xhr, status, err){
				if(error){error(err);}
			});
		}
		
		function getList(reply, callback, error){
			$.getJSON("/replies/pages/"+reply.rno+"/"+reply.page+".json", function(data){
				if(callback){callback(data.replyCnt, data.list);}
			}).fail(function(xhr, status, err){
				if(error){error(err);}
			});
		}
		
		function remove(rno, callback, error){
			$.ajax({
				type: "delete",
				url: "/replies/"+rno,
				success: function(result){
					if(callback){callback(result);}
				},
				error: function(xhr, status, err){
					if(error){error(err);}
				}
			});
		}
		
		function modify(reply, callback, error){
			$.ajax({
				type: "put",
				url: "/replies/"+reply.rno,
				data: JSON.stringify(reply),
				contentType: "application/json; charset=utf-8",
				success: function(result){
					if(callback){callback(result);}
				},
				error: function(xhr, status, err){
					if(error){error(err);}
				}
			});
		}
		
		return {add: add,
				get: get,
				getList: getList,
				remove: remove,
				modify: modify}
	}
})();

































var replyService = (function(){
	
	function add(reply, callback, error){
		$.ajax({
			type: "post",
			url: "/replies/new",
			data: JSON.stringify(reply),
			contentType: "application/json; charset=utf-8",
			success: function(result){
				if(callback){callback(result);}
			},
			error: function(xhr, status, err){
				if(error){error(err);}
			}
		});
	}
	
	function get(rno, callback, error){
		$.get("/replies/"+rno+".json",function(data){
			if(callback){callback(data);}
		}).fail(function(xhr, status, err){
			if(error){error(err);}
		});
	}
	
	function getList(reply, callback, error){
		var bno = reply.bno;
		var page = reply.page || 1;
		$.get("/replies/pages/"+bno+"/"+page+".json", function(data){
			//getList 컨트롤러에서는 댓글 목록과 댓글 전체 개수를 응답해준다.
			//따로 전달받지 않고 ReplyPageDTO객체로 한 번에 전달 받는다.
			if(callback){callback(data.replyCnt, data.list);}//callback함수에 전체 개수와 목록을 따로 전달해준다.
		}).fail(function(xhr, status, err){
			if(error){error(err);}
		});
	}
	
	function remove(rno, callback, error){
		$.ajax({
			type: "delete",
			url: "/replies/"+rno,
			success: function(result){
				if(callback){callback(result);}
			},
			error: function(xhr, status, err){
				if(error){error(err);}
			}
		});
	}
	
	function modify(reply, callback, error){
		$.ajax({
			type: "put",
			url: "/replies/"+reply.rno,
			data: JSON.stringify(reply),
			contentType: "application/json; charset=utf-8",
			success: function(result){
				if(callback){callback(result);}
			},
			error: function(xhr, status, err){
				if(error){error(err);}
			}
		});
	}
	
	function displayTime(timeValue){
		var today = new Date();//현재 날짜
		var replyTime = new Date(timeValue);//작성 날짜
		
		var gap = today.getTime() - replyTime.getTime();
		
		//하루를 밀리초로 만들어서 비교
		if(gap < 24 * 60 * 60 * 1000){
			//오늘일 경우
			//시분초
			var hh = replyTime.getHours();
			var mm = replyTime.getMinutes();
			var ss = replyTime.getSeconds();
			
			return [(hh > 9 ? '' : '0') + hh, (mm > 9 ? '' : '0') + mm, (ss > 9 ? '' : '0') + ss].join(' : ');
		}else{
			//오늘이 아닐 경우
			//년월일
			var yy = replyTime.getFullYear();
			var mo = replyTime.getMonth() + 1;
			var dd = replyTime.getDate();
			
			return [yy, (mo > 9 ? '' : '0') + mo, (dd > 9 ? '' : '0') + dd].join(' - ');
		}
	}
	
	return {add: add,
			get: get,
			getList: getList,
			remove: remove,
			modify: modify,
			displayTime: displayTime}
})();