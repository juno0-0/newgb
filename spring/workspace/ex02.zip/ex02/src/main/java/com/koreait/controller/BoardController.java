package com.koreait.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.koreait.domain.BoardVO;
import com.koreait.domain.Criteria;
import com.koreait.domain.PageDTO;
import com.koreait.service.BoardService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Controller	// 나 컨트롤러에요~
@Log4j
@RequestMapping("/board/*")	// url이 /board/로 시작하면 들어온다.
@AllArgsConstructor // BoardService에 생성자를 주입해서 객체화
public class BoardController {
	// Controller는 Service 객체에 의존한다.
	private BoardService service;
	
	@GetMapping("/list")
	public void list(Criteria cri, Model model) { // Model객체는 request.setAttribute()와 비슷한 역할
		// void로 리턴하면 /board/list.jsp 경로에 만들어진다.
		log.info("list");
		model.addAttribute("list", service.getList(cri));
		//getTotal(Criteria) : type과 keyword가 전달되면 검색된 게시글의 건수이며, 검색하지 않으면 전체 게시글의 건수이다.
		model.addAttribute("pageMaker", new PageDTO(cri, service.getTotal(cri)));
	}
	
	// 단순히 페이지를 이동하기 위해 사용
	@GetMapping("/register")
	public void register(@ModelAttribute("cri") Criteria cri) {log.info(cri);}
	
	@PostMapping("/register")
	public String register(BoardVO board, /*Model model*/ RedirectAttributes rttr) {
		log.info("register : " + board);
		
		if(board.getAttachList() != null) {
			board.getAttachList().forEach(log::info);
		}
		service.register(board);
		//model.addAttribute("result", board.getBno());
		// 새롭게 등록된 번호를 .jsp에 전달하기 위해서는 
		// request객체에 담아야 한다. 하지만 redirect방식으로 전송할 때에는
		// request가 초기화 된다. 따라서 세션에 있는 Flash 영역에 담아놓고
		// 초기화된 request객체에 전달해주면 결과값을 안전하게 이동시킬 수 있다.
		// 이 때 RedirectAttributes를 이용한다.
		rttr.addFlashAttribute("result", board.getBno());
		
		// 'redirect:' 접두어를 사용하면 스프링 MVC가 내부적으로
		// response.sendRedirect()를 처리해준다.
		return "redirect:/board/list";	// redirect로 전송하는 방법, forward는 default라 아무것도 안쓰면 forward
	}
	
	// 같은 내용을 2개 쓸 경우 새로 만드는게 아니라 경로만 추가하는 형식
	@GetMapping({"/get", "/modify"})
	// RequestParam은 객체와 일반 변수가 동시에 있을 때 분리하기 위해 작성한다.
	// 매개변수로 Long bno와 BoardVO board가 있을 경우 bno는 2개가 되는데
	// bno를 찾을 때 2개나 주니까 오류가 나서 이 bno를 찾는거니 하고 명시해 주는 것이 @RequestParam()의 역할
	public void get(@RequestParam("bno") Long bno, @ModelAttribute("cri") Criteria cri, Model model) {
		model.addAttribute("board", service.get(bno));
	}
	
	// 성공 시 result에 success를 담아서 view에 전달하기
	@PostMapping("/modify")
	public String modify(BoardVO board, Criteria cri, RedirectAttributes rttr) {
		log.info("modify : "+board);
		if(service.modify(board)) {
			rttr.addFlashAttribute("result", "success"); // Flash영역으로 request를 보내주는 것
		}else {
			rttr.addFlashAttribute("result", "fail");
		}
		// Flash는 세션의 남용을 방지하고자 1개의 파라미터만 전달할 수 있다.
		// 따라서 여러 개를 전달해야 할 때에는 컬렉션에 담아서 넘기거나
		// URL에 붙어서 전달하는 addAttribute()방식을 사용해야 한다.
		// 이미 위에서 result란 Key로 Flash에 데이터를 담았기 때문에 더 이상 담을 수 없다.
		// rttr.addFlashAttribute("pageNum", cri.getPageNum());
		// rttr.addFlashAttribute("amount", cri.getAmount());
		// model은 header에 담긴다.
		
		// 항상 컨트롤러에 있는 클래스 타입의 매개변수는 생성자를 통해서 파라미터 값으로 초기화 한다.
		// 만약 전달받은 파라미터 값에 매핑되는 생성자가 없다면 값을 전달받을 수 없다.
		// rttr.addFlashAttribute("cri", cri);
		// rttr.addAttribute("cri", cri);
		
		// 따라서 반드시 해당 객체의 생성자에 전달할 필드명과 일치하도록 설정해주어야 한다.
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		rttr.addAttribute("type", cri.getType());
		rttr.addAttribute("keyword", cri.getKeyword());
		return "redirect:/board/list";
	}
	
	@GetMapping("remove")
	// bno, pageNum, Amount가 파라미터로 들어오는 경우 @RequestParam이 없으면 전부 cri에서 찾아서 오류가 난다.
	public String remove(@RequestParam("bno") Long bno, Criteria cri, RedirectAttributes rttr) {
		log.info("remove : "+bno);
		if(service.remove(bno)) {
			rttr.addFlashAttribute("result", "success");
		}else {
			rttr.addFlashAttribute("result", "fail");
		}
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		rttr.addAttribute("type", cri.getType());
		rttr.addAttribute("keyword", cri.getKeyword());
		return "redirect:/board/list";
	}
}
