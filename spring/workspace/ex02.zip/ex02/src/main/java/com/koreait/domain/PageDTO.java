package com.koreait.domain;

import lombok.Getter;
import lombok.ToString;
//Setter를 쓸 일이 없어서 Getter랑 ToString만 생성
@Getter
@ToString
// pageDTO가 Criteria에게 의존하는 것, 생성자에서 cri 없으면 얘는 쓸 수 없기 때문에
public class PageDTO {
	private int startPage;
	private int endPage;
	private int realEnd;
	private boolean next, prev;
	private int total;
	private Criteria cri;
	
	public PageDTO(Criteria cri, int total) {
		this.cri = cri;
		this.total = total;
		
		//Math.ceil() : 올림
		this.endPage = (int)(Math.ceil(cri.getPageNum() / 10.0)) * 10;
		this.startPage = endPage - 9;
		
		this.realEnd = (int)(Math.ceil((total * 1.0) / cri.getAmount()));
		if(realEnd < this.endPage) {
			this.endPage = realEnd;
		}
		this.prev = this.startPage > 1;
		this.next = this.endPage < this.realEnd;
	}
}
