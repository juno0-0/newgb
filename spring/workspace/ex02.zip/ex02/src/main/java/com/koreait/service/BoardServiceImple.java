package com.koreait.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.koreait.domain.BoardAttachVO;
import com.koreait.domain.BoardVO;
import com.koreait.domain.Criteria;
import com.koreait.mapper.BoardAttachMapper;
import com.koreait.mapper.BoardMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

//주입을 인터페이스가 아니라 이쪽이 하는 것
@Service
@Log4j
@AllArgsConstructor
public class BoardServiceImple implements BoardService {
	
	//위에 AllArgsConstructor를 사용했기 때문에 @Setter를 하지 않는 것
	private BoardMapper mapper;
	private BoardAttachMapper attachMapper;
	
	@Transactional
	@Override
	public void register(BoardVO board) {
		log.info("register.............." + board);
		//이 메소드가 실행되면 board가 채워지기 때문에
		mapper.insertSelectKey_bno(board);
		//이걸 사용할 수 있는 것
		List<BoardAttachVO> attachList = board.getAttachList();
		
		//attachList가 비어있으면 종료
		//앞에 조건이 참이면 뒤의 조건식을 검사 안한다.
		if(attachList == null || attachList.size() <= 0) {
			return;
		}
		
		//람다식 forEach 사용
		attachList.forEach(attach -> {
			attach.setBno(board.getBno());
			attachMapper.insert(attach);
		});
	}

	@Override
	public BoardVO get(Long bno) {
		log.info("get.........." + bno);
		return mapper.read(bno);
	}

	/*
	 * 
	 * 3개 이상의 DML을 사용한 트랜젝션이 있다면,
	 * ROLLBACK의 우선순위가 가장 빠른 것을 가장 먼저 사용해주어야 한다.
	 * 만약 우선순위에 맞춰서 작성하지 않게 되면 전체 ROLLBACK이 된다.
	 * 
	 * 커밋이 자동으로 되는 기점에서 자동커밋이 안되는 경우가 발생하기 때문이다.
	 *  
	 */
	//수정은 기존 첨부파일을 전체 삭제 후 새로 등록한 것만 추가
	@Transactional
	@Override
	public boolean modify(BoardVO board) {
		log.info("modify..........." + board);
		
		//첨부파일이 게시글보다 우선순위가 높다(더 상세히 알고 싶다면 cardinality를 공부한다).
		//첨부파일 작업이 모두 잘 삭제되고, 게시글의 내용이 수정된다면,
		//첨부파일 추가 시 충돌이 발생되지 않는다.
		//만약 이 부분을 지키지 않을 경우 다른 트랜젝션에 의해 롤백될 수 있다(방지할 수 있지만, 안전하게 설계).
		//매퍼의 쿼리문을 실행했는데 잘 되던 다른 쿼리문이 반영되지 않는 경우 이 오류일 확률이 높다.
		//어떤 쿼리를 했는데 어디서 문제가 생기는지 팀장급에게 보고하자.
		
		//*테이블 2개 이상
		
		//1순위 : 전체 삭제
		attachMapper.deleteAll(board.getBno());
		//2순위 : 전체 수정(2개 이상)
		boolean modifyResult = mapper.update(board) == 1;
		//여기까지 진행이 끝난 후에만 insert()가 실행되어야 한다.
		
		//3순위 : DML
		if(modifyResult && board.getAttachList() != null) {
			if(board.getAttachList().size() != 0) {
				board.getAttachList().forEach(attach -> {
					attach.setBno(board.getBno());
					attachMapper.insert(attach);
				});
			}
		}
		return modifyResult;
	}

	@Transactional
	@Override
	public boolean remove(Long bno) {
		log.info("delete.........." + bno);
		//첨부파일이 먼저 삭제되야 하기 때문에 위에 쓴 것
		attachMapper.deleteAll(bno);
		return mapper.delete(bno) == 1;
	}

	@Override
	public List<BoardVO> getList() {
		log.info("getList.........");
		return mapper.getList();
	}

	@Override
	public List<BoardVO> getList(Criteria cri) {
		log.info("getList with criteria........."+cri);
		return mapper.getListWithPaging(cri);
	}

	@Override
	public int getTotal(Criteria cri) {
		return mapper.getTotal(cri);
	}

	@Override
	public List<BoardAttachVO> getAttachList(Long bno) {
		log.info("get Attach List By Bno" + bno);
		return attachMapper.findByBno(bno);
	}
}