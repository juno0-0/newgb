package com.koreait.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.koreait.domain.Criteria;
import com.koreait.domain.ReplyVO;

public interface ReplyMapper {
	public int insert(ReplyVO reply);
	public ReplyVO read(Long rno);
	// XML에 데이터를 넘겨주는 방식 3가지
	// 1. 객체 생성
	// 2. Map
	// 3. @Param("key")
	public List<ReplyVO> getListWithPaging(@Param("cri") Criteria cri, @Param("bno") Long bno);
	public int delete(Long rno);
	public int update(ReplyVO reply);
	public int getTotal(Long bno);
}
