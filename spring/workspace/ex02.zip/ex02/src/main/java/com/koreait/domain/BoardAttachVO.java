package com.koreait.domain;

import lombok.Data;

@Data
public class BoardAttachVO {
	//사용하지 않음?
	private final String rootPath = "C:\\upload";
	private String uuid;
	private String uploadPath;
	private String fileName;
	private boolean fileType;
	private Long bno;
}
