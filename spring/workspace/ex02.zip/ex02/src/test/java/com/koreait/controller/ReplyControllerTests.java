package com.koreait.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({"file:src/main/webapp/WEB-INF/spring/root-context.xml",
		"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"})
@Log4j
@WebAppConfiguration
public class ReplyControllerTests {
	@Setter(onMethod_ = @Autowired)
	private WebApplicationContext wac;
	
	// 가짜 MVC
	// 마치 브라우저에서 사용하는 것처럼 만들어서 Controller를 실행해 볼 수 있다.
	private MockMvc mockMvc; // 주입을 받는게 아니라 wac를 통해서 build 하는 것
	
	@Before	// org.JUnit, 모든 테스트 전에 실행되는 어노테이션
	public void setup() {
		// WebApplicationContext를 통해 ServletContext를 빌드한다.
		// builder가 아니고 builder"s"
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		// webAppContextSetup을 통해 MockMvc를 Build한다.
	}
	
	@Test
	public void testGetList() throws Exception {
		log.info(mockMvc.perform(MockMvcRequestBuilders.get("/replies/pages/{bno}/{page}")
				.param("bno", "5242820")
				.param("page", "1"))
		.andReturn()
		.getModelAndView()
		.getModelMap());
	}
}
