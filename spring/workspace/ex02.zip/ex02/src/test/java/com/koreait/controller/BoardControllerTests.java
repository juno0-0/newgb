package com.koreait.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration	// Servlet의 ServletContext를 이용하기 위함
@ContextConfiguration({
	"file:src/main/webapp/WEB-INF/spring/root-context.xml",
	"file:src/main/webapp/WEB-INF/spring/appServlet/servlet-context.xml"
})
@Log4j
public class BoardControllerTests {
	@Setter(onMethod_ = @Autowired)
	private WebApplicationContext wac;
	
	// 가짜 MVC
	// 마치 브라우저에서 사용하는 것처럼 만들어서 Controller를 실행해 볼 수 있다.
	private MockMvc mockMvc; // 주입을 받는게 아니라 wac를 통해서 build 하는 것
	
	@Before	// org.JUnit, 모든 테스트 전에 실행되는 어노테이션
	public void setup() {
		// WebApplicationContext를 통해 ServletContext를 빌드한다.
		// builder가 아니고 builder"s"
		this.mockMvc = MockMvcBuilders.webAppContextSetup(wac).build();
		// webAppContextSetup을 통해 MockMvc를 Build한다.
	}

	@Test
	public void testRemove() throws Exception{
		log.info(mockMvc.perform(MockMvcRequestBuilders.get("/board/remove")
				.param("bno", "100")) // BoardController.java에 parameter를 보내주는 것
				.andReturn()
				.getFlashMap());
	}
	
//	@Test
//	public void testModify() throws Exception{
//		log.info(mockMvc.perform(MockMvcRequestBuilders.post("/board/modify")
//						.param("bno", "21")
//						.param("title", "수정된 글 제목")
//						.param("content", "수정된 글 내용")
//						.param("writer", "admin"))
//					.andReturn()
//					.getFlashMap());
//	}
	
//	@Test
//	public void testGet() throws Exception{
//		log.info(mockMvc.perform(MockMvcRequestBuilders.get("/board/get")
//						.param("bno", "21"))
//					.andReturn()
//					.getModelAndView()
//					.getModelMap());
//	}
	
//	@Test
//	public void testRegister() throws Exception{
//		log.info(mockMvc.perform(MockMvcRequestBuilders.post("/board/register")
//						.param("title", "테스트 새 글 제목")		// 값을 전달하는 것
//						.param("content", "테스트 새 글 내용")
//						.param("writer", "test123"))
//					.andReturn()
//					//.getFlashMap());	// Flash를 사용했으면 여기서도 FlashMap을 사용한다.
//					.getModelAndView()
//					.getViewName());	// 어디로 응답하는지 확인
//	}
	
//	@Test
//	public void testList() throws Exception{
//		log.info(mockMvc.perform(MockMvcRequestBuilders.get("/board/list"))	// 여기서 get은 GET방식
//					.andReturn()		// 응답된 결과값을 통해
//					.getModelAndView()	// Model에 어떤 데이터가 담겨 있는지를
//					.getModelMap());	// Map 형식으로 확인
//	}
}
