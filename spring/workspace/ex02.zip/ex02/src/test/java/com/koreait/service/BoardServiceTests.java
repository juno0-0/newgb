package com.koreait.service;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.koreait.domain.BoardVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class) //테스트 코드가 스프링을 실행
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")//지정된 클래스나 문자열을 이용해서 필요한 객체들을 스프링 내에 객체로 등록
@Log4j
public class BoardServiceTests {
	@Setter(onMethod_ = @Autowired)
	private BoardService service;
	//자식 클래스가 여러 개일 경우 @Service를 하나하나 붙여주는게 아니라
	//<bean>으로 생성하되 id를 다 다르게 적용하고
	//여기서 사용할 때는 @Qualifier("id")를 사용한다.
	
//	@Test
//	public void testExist() {
//		assertNotNull(service);
//		log.info(service);
//	}
	
//	@Test
//	public void testRegister() {
//		BoardVO board = new BoardVO();
//		board.setTitle("테스트 제목");
//		board.setContent("테스트 내용");
//		board.setWriter("테스트 작성자");
//		service.register(board);
//	}
	
//	@Test
//	public void testGet() {
//		service.get(2L);
//	}
	
//	@Test
//	public void testList() {
//		service.getList();
//	}
	
//	@Test
//	public void testUpdate() {
//		BoardVO board = new BoardVO();
//		board.setBno(2L);
//		board.setTitle("수정된 테스트 제목");
//		board.setContent("수정된 테스트 내용");
//		if(service.modify(board)) {
//			log.info("성공");
//		}else {
//			log.info("실패");
//		}
//	}
	
	
}
