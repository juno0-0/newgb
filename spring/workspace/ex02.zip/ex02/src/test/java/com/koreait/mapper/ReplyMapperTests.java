package com.koreait.mapper;

import java.util.List;
import java.util.stream.IntStream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.koreait.domain.BoardVO;
import com.koreait.domain.Criteria;
import com.koreait.domain.ReplyVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyMapperTests {
	@Setter(onMethod_ = @Autowired)
	private ReplyMapper mapper;
	
	@Setter(onMethod_ =@Autowired)
	private BoardMapper board;
	
	Long[] arBno = {4194362L, 4194361L, 4194341L, 4194340L, 4194339L};
	
	// 수정 테스트
	@Test
	public void testUpdate() {
		ReplyVO reply = mapper.read(2L);
		reply.setReply("수정 테스트입니다.");
		log.info("UPDATE COUNT : "+mapper.update(reply));
	}
	
	// 삭제 테스트
//	@Test
//	public void testDelete() {
//		log.info("DELETE COUNT : "+mapper.delete(1L));
//	}
	
	// 전체보기 테스트
//	@Test
//	public void testGetListWithPaging() {
//		mapper.getListWithPaging(4194362L).forEach(reply -> log.info(reply));
//	}
	
	// 상세보기 테스트
//	@Test
//	public void testRead() {
//		log.info(mapper.read(3L));
//	}
	
	// 작성 테스트
//	@Test
//	public void testInsert() {
//		List<BoardVO> boards = board.getListWithPaging(new Criteria(1, 5));
//		IntStream.rangeClosed(1, 10).forEach(reply -> {
//			ReplyVO r = new ReplyVO();
//			r.setBno(boards.get(reply % 5).getBno());
//			r.setReply("테스트 댓글"+reply);
//			r.setReplyer("테스트 작성자"+reply);
//			log.info(mapper.insert(r));
//		});
//	}
	
//	@Test
//	public void test() {
//		log.info(mapper);
//	}
}
