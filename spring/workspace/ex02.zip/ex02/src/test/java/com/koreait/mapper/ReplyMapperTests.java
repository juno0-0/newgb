package com.koreait.mapper;

import java.io.InputStream;
import java.util.List;
import java.util.stream.IntStream;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.koreait.domain.BoardVO;
import com.koreait.domain.Criteria;
import com.koreait.domain.ReplyVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

//RunWith(SpringJUnit4ClassRunner의 자식이며,
//4.3버전 이상부터 사용가능한 확장판이다.
@RunWith(SpringRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyMapperTests {
	@Setter(onMethod_ = @Autowired)
	private ReplyMapper mapper;
	
	@Setter(onMethod_ = @Autowired)
	private BoardMapper board;
	
	private Long[] arBno = {5242932L, 5242931L, 5242930L, 5242929L, 5242928L};
	
//	@Test
//	public void testUpdate() {
//		ReplyVO reply = mapper.read(19L);
//		reply.setReply("안녕하세요? 수정했어요");
//		
//		log.info(mapper.update(reply));
//	}
	
//	@Test
//	public void testDelete() {
//		log.info("DELETE COUNT : "+mapper.delete(24L));
//	}
	
//	@Test
//	public void testInsert() {
//		List<BoardVO> boards = board.getListWithPaging(new Criteria(1, 5));
//		IntStream.rangeClosed(1, 10).forEach(reply -> {
//			ReplyVO r = new ReplyVO();
//			r.setBno(boards.get(reply % 5).getBno());
//			r.setReply("테스트입니다"+reply);
//			r.setReplyer("테스트작성자"+reply);
//			log.info(mapper.insert(r));
//		});
//	}
	
	@Test
	public void testGetListWithPaging() {
		mapper.getListWithPaging(arBno[3]).forEach(reply -> log.info(reply));
	}
	
//	@Test
//	public void testRead() {
//		log.info(mapper.read(10L));
//	}
	
//	@Test
//	public void testInsert() {
//		ReplyVO reply = new ReplyVO();
//		reply.setBno(5242931L);
//		reply.setReply("테스트댓글");
//		reply.setReplyer("admin");
//		log.info("INSERT COUNT : "+mapper.insert(reply));
//	}
	
//	@Test
//	public void testMapper() {
//		log.info(mapper);
//	}
}
