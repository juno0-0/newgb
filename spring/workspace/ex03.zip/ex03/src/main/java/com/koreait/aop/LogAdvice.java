package com.koreait.aop;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

import lombok.extern.log4j.Log4j;

@Aspect
@Log4j
//<bean>과 같이 객체를 만들어주는 것
@Component
public class LogAdvice {
	
	//AOP를 사용하기 위해서는 종단관심사에 Proxy설정이 되어야 한다.
	//이는 root-context.xml에 auto로 설정을 해놓는다.
	//횡단관심사에서 작성한 모듈은 Proxy설정이 되어 있는 Target(주객체)에게
	//언제 결합해야 되는 지를 알려주어야 하는데, 이를 pointcut이라고 한다.
	//Target(주객체)에 있는 종단관심사가 호출되면 pointcut에 작성된 Target(메소드)
	//의 전체 정보를 가지고 올 수 있는 객체가 바로 JoinPoint(결합되는 지점)이다.
	
	//AOP 문법
	//execution...은 AspectJ의 표현식이며, 맨 앞의 *은 접근제어자를 의미하고,
	//맨 마지막의 *은 클래스의 이름과 메소드의 이름을 의미한다.
	//..은 0개 이상이라는 의미이다.
	
	//모든 접근 제어자의 SampleService이름이 붙은 모든 클래스에서 모든 메소드 중
	//매개변수가 0개 이상이라는 뜻.
	
	//맨 앞의 *은 모든 접근 제어자
	//중간에 있는 *은 SampleServiceOOO라고 되있는거 전부라는 의미
	//*(..) : 이름이 뭐든 상관없고 매개변수가 어떤거든 상관없다.
	@Before("execution(* com.koreait.service.SampleService*.*(..))")
	public void logBefore() {
		//doAdd가 호출되자마자 실행
		log.info("=======Before=======");
	}
	
	@After("execution(* com.koreait.service.SampleService*.*(..))")
	public void logAfter() {
		//doAdd가 호출되자마자 실행
		log.info("=======After=======");
	}
	
	@AfterReturning("execution(* com.koreait.service.SampleService*.*(..))")
	public void logAfterReturning() {
		//doAdd가 호출되자마자 실행
		log.info("=======AfterReturning=======");
	}
	
	//args(매개변수명, 매개변수명, ...)
	//호출된 종단관심사의 매개변수를 횡단관심사로 전달받을 때에는 매개변수의 개수와 타입에 맞게
	//작성해주어야 하며, args에 해당 매개변수의 이름을 동일하게 작성해주어야 한다.
	
	//doAdd라는 메소드 중 매개변수를 (String, String)으로 받는 애가 들어왔을 때 매개변수를 str1과 str2에 넣어줘(여기서 str1과 str2는 밑의 메소드의 매개변수의 이름)
	@Before("execution(* com.koreait.service.SampleService*.doAdd(String, String)) && args(str1, str2)")
	public void logBeforeWithParam(String str1, String str2) {
		log.info("str1 : "+str1);
		log.info("str2 : "+str2);
	}
	
	//pointcut : 횡단관심사와 종단관심사의 결합되는 지점을 결정하는 것, 언제 연결해줄까라고 묻는 것
	//연결이 되고 나면 pointcut에 있는 매개변수가 타겟이 되는 것
	
	//예외를 처리할 때는 @AfterThrowing
	//pointcut만 쓸 경우 pointcut=는 생략이 가능하고 다른걸 사용할 경우 pointcut=를 명시해준다.
	//throwing에는 매개변수로 받는 예외의 객체를 넣는 것
	@AfterThrowing(pointcut="execution(* com.koreait.service.SampleService*.*(..))", throwing="exception")
	public void logException(Exception exception) {
		log.info("Exception................");
		log.info("exception : "+exception);
	}
	
	//메소드를 실행하면 이쪽으로 들어오는거라서 이쪽에서 메소드를 실행해줘야 한다.
	//ProceedingJoinPoint : Around를 했을 때 해당 메소드에 대한 모든 정보를 가지고 있는 애
	@Around("execution(* com.koreait.service.SampleService*.*(..))")
	public Object logTime(ProceedingJoinPoint pjp) {
		Long start = System.currentTimeMillis();
		
		log.info("핵심 로직 : "+pjp.getTarget());
		//Object[]로 리턴하기 때문에 Arrays.toString()을 사용
		log.info("파라미터 : "+Arrays.toString(pjp.getArgs()));
		
		Object result = null;
		
		try {
			//실행한 메소드의 리턴값 호출
			//얘를 안하면 메소드의 정보만 가져오고 실행을 안한 것
			result = pjp.proceed();
		} catch (Throwable e) {
			e.printStackTrace();
		}
		
		Long end = System.currentTimeMillis();
		log.info("걸린 시간 : " + (end-start));
		return result;
	}
}