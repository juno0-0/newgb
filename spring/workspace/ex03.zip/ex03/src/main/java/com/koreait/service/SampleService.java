package com.koreait.service;

public interface SampleService {
	public Integer doAdd(String st1, String st2) throws Exception;
}