package com.koreait.aop;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.koreait.service.SampleService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class SampleServiceTests {
	@Setter(onMethod_ = @Autowired)
	private SampleService service;

	@Test
	public void testAdd() throws Exception {
		log.info(service.doAdd("123", "456"));
		//log.info(service.doAdd("abc", "456"));
	}

//	@Test
//	public void testClass() {
//		//프록시 객체가 잘 연결될껀지부터 테스트
//		log.info(service);
//		log.info(service.getClass().getName());
//	}
}