package com.koreait.domain;

import lombok.Data;

@Data
public class AttachDTO {
	private String fileName;
	private String uuid;
	private String uploadPath;
	private boolean image;
}
