package com.koreait.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.koreait.domain.AllFileDTO;
import com.koreait.domain.AttachDTO;

import lombok.extern.log4j.Log4j;
import net.coobird.thumbnailator.Thumbnailator;

//.jsp로 보낼꺼라서 Controller를 사용한다.
@Controller
@Log4j
//@RequestMapping을 안쓰는건 해당 메소드에서 알려주기 때문이다.
//단, RequestMapping을 안쓰면 action에서 /를 반드시 생략한다.
public class UploadController {
	
	@GetMapping("/uploadForm")
	public void uploadForm() {
		log.info("upload form");
	}
	
	@GetMapping("/uploadAjax")
	public void uploadAjax() {
		log.info("upload ajax");
	}

	
	@PostMapping("/uploadFormAction")
	//외부에서 여러 개의 파일이 전달될 수 있으므로 배열로 받는다.
	//jsp에서 배열로 첨부파일 여러개를 보냈기 때문에 그걸 받는 것
	public void uploadFormPost(MultipartFile[] uploadFile) {
		//업로드 할 경로
		String uploadFolder = "C:\\upload";
		
		//각 multipart 객체를 순서대로 가져온 후 
		for(MultipartFile multipartFile : uploadFile) {
			
			//원하는 데이터를 메소드로 가져온다.
			log.info("========================");
			log.info("업로드 파일 명 : "+multipartFile.getOriginalFilename());
			log.info("업로드 파일 크기 : "+multipartFile.getSize());
			
			//전체 경로를 File 객체에 담아준다.
			//File 타입으로 해놔야 byte전송이 된다.
			File saveFile = new File(uploadFolder, multipartFile.getOriginalFilename());
			try {
				//해당 경로에 파일을 업로드해준다. 
				//transferTo : 해당 경로에 해당 파일의 바이트가 입력되게 하는 역할
				multipartFile.transferTo(saveFile);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	@PostMapping("/uploadAjaxAction")
	public ResponseEntity<AllFileDTO> uploadAjaxAction(MultipartFile[] uploadFile) {
		log.info("upload ajax post............");
		
		String uploadFolder = "C:\\upload";
		String uploadFolderPath = getFolder();
		//사용자가 업로드를 한 시간인 년, 월, 일을 디렉토리로 만드는 getFolder()를 사용한다.
		File uploadPath = new File(uploadFolder, uploadFolderPath);
		
		//모든 첨부파일을 가지고 있는 DTO
		AllFileDTO allFile = new AllFileDTO();
		//첨부파일 업로드 성공 시 들어갈 객체
		List<AttachDTO> succeedList = new ArrayList<>();
		//첨부파일 업로드 실패 시 들어갈 객체
		List<AttachDTO> failureList = new ArrayList<>();
		
		
		//JDK 11인가 13부터 var를 사용할 수 있다.
		
		//만약 해당 디렉토리가 존재하지 않으면
		if(!uploadPath.exists()) {
			//만들어준다.
			uploadPath.mkdirs();
		}
		
		for(MultipartFile multipartFile : uploadFile) {
			log.info("========================");
			log.info("업로드 파일 명 : "+multipartFile.getOriginalFilename());
			log.info("업로드 파일 크기 : "+multipartFile.getSize());

			//첨부파일 정보를 가지고 있는 객체
			//for문 들어올 때마다 초기화
			AttachDTO attachDTO = new AttachDTO();
			
			String uploadFileName = multipartFile.getOriginalFilename();
			System.out.println(uploadFileName);
			//IE에서는 파일 이름만 가져오지 않고 전체 경로를 가져오기 때문에 마지막에 위치한 파일 이름만 가져오도록 한다.
			//IE 이외의 브라우저에서는 \\가 없기 때문에 -1 + 1로 연산되어 0번째 즉, 파일이름을 의미한다.
			//lastIndexOf : 뒤에서부터 찾는다.
			uploadFileName = uploadFileName.substring(uploadFileName.lastIndexOf("\\") + 1);
			
			log.info("실제 파일 명 : "+uploadFileName);
			attachDTO.setFileName(uploadFileName);
			//거의 모든 중복을 막는 코드
			//랜덤한 UUID를 담아 놓는다.
			UUID uuid = UUID.randomUUID();
			//파일 이름이 중복되더라도 이름 앞에 UUID를 붙여주기 때문에 중복될 가능성이 희박하다.
			//덮어씌워지는 것을 방지한다.
			uploadFileName = uuid.toString() + "_" + uploadFileName;
			InputStream in = null; 
			
			try {
				File saveFile = new File(uploadPath, uploadFileName);
				//saveFile의 경로에 byte로 첨부파일 전송
				multipartFile.transferTo(saveFile);
				
				in = new FileInputStream(saveFile);
				
				attachDTO.setUuid(uuid.toString());
				attachDTO.setUploadPath(uploadFolderPath);
				
				if(checkImg(saveFile)) {
					attachDTO.setImage(true);
					
					//Stream : 파일을 통신할 때 byte가 이동할 경로
					//그냥 saveFile을 쓰게 되면 이름 구분을 할 수 없기 때문에 새로 new File() 해준 것
					//첨부파일이 이미지일 경우 썸네일을 내보내준다.
					FileOutputStream thumbnail = new FileOutputStream(new File(uploadPath, "s_"+uploadFileName));
					
					//Thumbnailator : 썸네일 라이브러리
					//사용자가 첨부한 파일은 multipartFile(InputStream)을 통해서 가져오고,
					//원하는 width, height를 지정한 후 변경된 이미지 파일을 FileOutputStream 객체를 통해서 업로드한다.
					//Thumbnailator는 중간관리 역할을 한다.
					//width와 height를 입력해도 비율을 유지하기 때문에 입력한 값으로 안들어갈 수도 있다.
					Thumbnailator.createThumbnail(in, thumbnail, 100, 100);
					
					//사용이 끝나면 닫아준다.
					thumbnail.close();
				}
				succeedList.add(attachDTO);				
			} catch (Exception e) {
				failureList.add(attachDTO);
				log.error(e.getMessage());
			} finally {
				if(in != null) {
					try {
						in.close();
					} catch (IOException e) {
						e.printStackTrace();
						throw new RuntimeException();
					}
				}
			}
		}
		allFile.setSucceedList(succeedList);
		allFile.setFailureList(failureList);
		return new ResponseEntity<AllFileDTO>(allFile, HttpStatus.OK);
	}
	
	@GetMapping("/display")
	@ResponseBody
	//썸네일 뿌려주기
	public ResponseEntity<byte[]> getFile(String fileName){
		//"C:\\upload\\"+fileName 경로에 있는 파일을 객체에 담아놓는다.
		File file = new File("C:\\upload\\"+fileName);
		
		ResponseEntity<byte[]> result = null;
		//HttpHeaders : 요청과 응답을 담아놓는 곳
		//HttpRequest와 HttpResponse의 부모
		HttpHeaders header = new HttpHeaders();
		
		try {
			//타입을 얻어와서 Content-Type이라는 Key의 value에 넣는다.
			header.add("Content-Type",Files.probeContentType(file.toPath()));
			
			//copyToByteArray : 지정한 InputStream의 내용을 새로운 byte[]에 copy하고 완료되면 Stream을 닫는다.
			//리턴값은 copy된 새로운 byte[]를 리턴한다(빈값이 들어올 수 있다).
			result = new ResponseEntity<byte[]>(FileCopyUtils.copyToByteArray(file), header, HttpStatus.OK);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return result;
	}
	
	//첨부파일 다운로드
	@GetMapping(value="/download", produces= {MediaType.APPLICATION_OCTET_STREAM_VALUE})
	@ResponseBody
	//@RequestHeader : HTTP 요청 헤더 값을 컨트롤러 메서드의 파라미터로 전달한다
	public ResponseEntity<Resource> downloadFile(String fileName, @RequestHeader("User-Agent") String userAgent) {
		log.info("download file : "+fileName);
		//Resource로 보낼 때는 APPLICATION_OCTET_STREAM_VALUE로 보내야 한다.
		Resource resource = new FileSystemResource("C:\\upload\\"+fileName);
		log.info("resource : "+resource);
		
		//가져온 fileName 
		String resourceName = resource.getFilename();
		
		//uuid가 제거된 파일 이름
		String originalName = resourceName.substring(resourceName.indexOf("_") + 1);
		
		HttpHeaders headers = new HttpHeaders();
		
		try {
			String downloadName = null;
			
			if(userAgent.contains("Trident")) {
				//Trident : MSIE
				log.info("IE Browser");
				//익스플로러는 디렉토리 문자열 형식이 다르기 때문에 수정해준다.
				//downloadName = URLEncoder.encode(originalName, "UTF-8").replaceAll("\\", " ");
				downloadName = URLEncoder.encode(originalName, "UTF-8");
			}else if(userAgent.contains("Edg")) {
				log.info("Edg");
				downloadName = URLEncoder.encode(originalName, "UTF-8");
			}else {
				log.info("Chrome Browser");
				downloadName = new String(originalName.getBytes("UTF-8"), "ISO-8859-1");
			}
			
			//다운로드 시 저장되는 이름 : Content-Disposition
			//attachment;를 써주어야 첨부파일로 인식한다.
			//new String(byte[], charset) : 해당 바이트배열을 charset으로 설정한다.
			//getBytes(charset) : 해당 문자열을 charset으로 변경하기 위해 byte 배열로 리턴한다.
			//resourceName.getBytes("UTF-8") 다시 바이트 배열로 만들었다가 문자열로 하는 이유는
			//저 resourceName도 인코딩하기 위해서이다.
			headers.add("Content-Disposition", "attachment; filename="+downloadName);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Resource>(resource, headers, HttpStatus.OK);
	}
	
	//첨부파일 삭제하기
	//파일 이름이 길기 때문에 POST를 쓴 것
	@PostMapping("/deleteFile")
	@ResponseBody
	public ResponseEntity<String> deleteFile(String fileName, String type){
		log.info("deleteFile : "+fileName);
		File file = null;
		try {
			//Encode는 포괄적이다.
			//단순히 charset만 하는게 아니다.
			//encode : 헤더에 담은 데이터에 명령어로 인식될 수 있거나 특수문자 등이 포함되어 있을 때에는
			//			해당 문자에 대한 코드번호로 대체하는 작업
			// \\ ---> %2F : encoding
			// %2F ---> \\ : decoding
			
			//여기서 decode를 쓰는 이유는 2010%2F05%2F28%2F를 2010\\05\\28로 다시 바꾸기 위해서이다.
			file = new File("C:\\upload\\"+URLDecoder.decode(fileName, "UTF-8"));
			file.delete();
			
			//원본 이미지파일 삭제하기
			if(type.equals("image")) {
				//서버 디렉토리 설정 시 "s_"를 피해주세요.
				String imgFileName = file.getPath().replace("s_", "");
				log.info("file.getPath() : "+file.getPath());
				file = new File(imgFileName);
				file.delete();
			}
			
		} catch (UnsupportedEncodingException e) {
			//없는 charset을 사용할 경우 이쪽으로 들어옴
			e.printStackTrace();
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<String>("deleted", HttpStatus.OK);
	}
	
	private String getFolder() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		//현재 날짜에서 -를 \\로 변경해준다.
		Date date = new Date();
		String str = sdf.format(date);
		//File.separator는 \\혹은 /, 상위디렉토리에서 하위로 갈 때의 문자열 형식
		return str.replace("-", File.separator);
	}
	
	private boolean checkImg(File file) throws IOException {
		//사용자가 업로드한 파일의 타입 중 앞부분이 image로 시작한다면 이미지 파일이다.
		//파일이 image 타입인지 확인하는 것
		//마임타입 : 해당 데이터의 타입
		return Files.probeContentType(file.toPath()).startsWith("image");
	}
}
