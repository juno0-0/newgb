package com.koreait.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.log4j.Log4j;

//.jsp로 보낼꺼라서 Controller를 사용한다.
@Controller
@Log4j
//@RequestMapping을 안쓰는건 해당 메소드에서 알려주기 때문이다.
//단, RequestMapping을 안쓰면 action에서 /를 반드시 생략한다.
public class UploadController {
	
	@GetMapping("/uploadForm")
	public void uploadForm() {
		log.info("upload form");
	}
	
	@GetMapping("/uploadAjax")
	public void uploadAjax() {
		log.info("upload ajax");
	}

	
	@PostMapping("/uploadFormAction")
	//외부에서 여러 개의 파일이 전달될 수 있으므로 배열로 받는다.
	//jsp에서 배열로 첨부파일 여러개를 보냈기 때문에 그걸 받는 것
	public void uploadFormPost(MultipartFile[] uploadFile) {
		//업로드 할 경로
		String uploadFolder = "C:\\upload";
		
		//각 multipart 객체를 순서대로 가져온 후 
		for(MultipartFile multipartFile : uploadFile) {
			
			//원하는 데이터를 메소드로 가져온다.
			log.info("========================");
			log.info("업로드 파일 명 : "+multipartFile.getOriginalFilename());
			log.info("업로드 파일 크기 : "+multipartFile.getSize());
			
			//전체 경로를 File 객체에 담아준다.
			//File 타입으로 해놔야 byte전송이 된다.
			File saveFile = new File(uploadFolder, multipartFile.getOriginalFilename());
			try {
				//해당 경로에 파일을 업로드해준다. 
				//transferTo : 해당 경로에 해당 파일의 바이트가 입력되게 하는 역할
				multipartFile.transferTo(saveFile);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	@PostMapping("/uploadAjaxAction")
	public void uploadAjaxAction(MultipartFile[] uploadFile) {
		log.info("upload ajax post............");
		
		String uploadFolder = "C:\\upload";
		//사용자가 업로드를 한 시간인 년, 월, 일을 디렉토리로 만드는 getFolder()를 사용한다.
		File uploadPath = new File(uploadFolder, getFolder());
		
		//JDK 11인가 13부터 var를 사용할 수 있다.
		
		//만약 해당 디렉토리가 존재하지 않으면
		if(!uploadPath.exists()) {
			//만들어준다.
			uploadPath.mkdirs();
		}
		
		for(MultipartFile multipartFile : uploadFile) {
			log.info("========================");
			log.info("업로드 파일 명 : "+multipartFile.getOriginalFilename());
			log.info("업로드 파일 크기 : "+multipartFile.getSize());
			
			String uploadFileName = multipartFile.getOriginalFilename();
			//IE에서는 파일 이름만 가져오지 않고 전체 경로를 가져오기 때문에 마지막에 위치한 파일 이름만 가져오도록 한다.
			//IE 이외의 브라우저에서는 \\가 없기 때문에 -1 + 1로 연산되어 0번째 즉, 파일이름을 의미한다.
			//lastIndexOf : 뒤에서부터 찾는다.
			uploadFileName = uploadFileName.substring(uploadFileName.lastIndexOf("\\") + 1);
			
			log.info("실제 파일 명 : "+uploadFileName);
			
			//거의 모든 중복을 막는 코드
			//랜덤한 UUID를 담아 놓는다.
			UUID uuid = UUID.randomUUID();
			//파일 이름이 중복되더라도 이름 앞에 UUID를 붙여주기 때문에 중복될 가능성이 희박하다.
			//덮어씌워지는 것을 방지한다.
			uploadFileName = uuid.toString() + "_" + uploadFileName;
			
			File saveFile = new File(uploadPath, uploadFileName);
			try {
				//saveFile의 경로에 byte로 첨부파일 전송
				multipartFile.transferTo(saveFile);
			} catch (Exception e) {
				log.error(e.getMessage());
			}
		}
	}
	
	private String getFolder() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		//현재 날짜에서 -를 \\로 변경해준다.
		Date date = new Date();
		String str = sdf.format(date);
		//File.separator는 \\혹은 /, 상위디렉토리에서 하위로 갈 때의 문자열 형식
		return str.replace("-", File.separator);
	}
	
	private boolean checkImg(File file) throws IOException {
		//사용자가 업로드한 파일의 타입 중 앞부분이 image로 시작한다면 이미지 파일이다.
		//파일이 image 타입인지 확인하는 것
		//마임타입 : 해당 데이터의 타입
		return Files.probeContentType(file.toPath()).startsWith("image");
	}
}
