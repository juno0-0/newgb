package com.team4.app.review;


import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.fileName.dao.FileNameDAO;
import com.team4.app.review.dao.ReviewDAO;
import com.team4.app.review.vo.ReviewVO;

public class ReviewWriteOkAction implements Action{
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		ReviewVO r_vo = new ReviewVO();
		ReviewDAO r_dao = new ReviewDAO();
		FileNameDAO f_dao = new FileNameDAO();
		ActionForward forward = null;
		
		String saveFoleder = "D:\\0900_gb_bjh\\jsp\\workspace\\dg_project\\WebContent\\files";
		
		//5MB
		int fileSize = 5 * 1024 * 1024;
		
		MultipartRequest multi = null;
		
		multi = new MultipartRequest(req, saveFoleder, fileSize, "UTF-8", new DefaultFileRenamePolicy());
		
		Enumeration<String> names = multi.getFileNames();
		while(names.hasMoreElements()) {
			String data = names.nextElement();
			String systemName = multi.getFilesystemName(data);
		}
		
		r_vo.setMemberId(multi.getParameter("memberId"));
		r_vo.setTrainerId(multi.getParameter("trainerId"));
		r_vo.setReviewContent(multi.getParameter("reviewContent"));

		if(r_dao.reviewWrite(r_vo)) {
			//6번 카테고리의 r_dao.getReviewNum()번 글의 첨부파일
			if(f_dao.insertFiles(6, r_dao.getReviewNum(), multi)) {
				forward = new ActionForward();
				forward.setRedirect(true);
				forward.setPath(req.getContextPath() + "/review/ReviewList.rv");
			}
		}
				
		return forward;
	}
}
