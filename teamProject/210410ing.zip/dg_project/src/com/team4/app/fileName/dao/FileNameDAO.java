package com.team4.app.fileName.dao;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.oreilly.servlet.MultipartRequest;
import com.team4.app.fileName.vo.FileNameVO;
import com.team4.mybatis.config.SqlMapConfig;

public class FileNameDAO {
	SqlSessionFactory session_f = SqlMapConfig.getSqlMapInstance();
	SqlSession session;
	
	public FileNameDAO() {
		session = session_f.openSession(true);
	}
	
	//리뷰 첨부파일 등록하기
	public boolean insertFiles(int categoryNum, int boardNum, MultipartRequest multi) {
		boolean check = true;
		FileNameVO f_vo = new FileNameVO();
		Enumeration<String> files = multi.getFileNames();
		
		while(files.hasMoreElements()) {
			String data = files.nextElement();
			String systemName = multi.getFilesystemName(data);
			if(systemName == null) {
				continue;
			}
			
			f_vo.setCategoryNum(categoryNum);
			f_vo.setBoardNum(boardNum);
			f_vo.setFileName(systemName);
			
			if(session.insert("Files.reviewInsert", f_vo) != 1) {
				check = false;
				break;
			}
		}
		return check;
	}
	
	//리뷰 첨부파일 가져오기
	public List<FileNameVO> getReviewFile(int reviewNum){
		HashMap<String, Integer> map = new HashMap<>();
		map.put("categoryNum", 6);
		map.put("reviewNum", reviewNum);
		
		return session.selectList("Files.getReviewFile", map);
	}
}
