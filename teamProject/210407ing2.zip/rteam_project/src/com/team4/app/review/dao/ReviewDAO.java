package com.team4.app.review.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.team4.app.review.vo.ReviewVO;
import com.team4.mybatis.config.SqlMapConfig;

public class ReviewDAO {
	SqlSessionFactory session_f = SqlMapConfig.getSqlMapInstance();
	SqlSession session;
	
	public ReviewDAO() {
		session = session_f.openSession(true);
	}
	
	/**
	 * 
	 * @param r_vo
	 * @return boolean
	 * 
	 * true면 등록 성공<br>false면 등록 실패
	 * 
	 */
	public boolean reviewWrite(ReviewVO r_vo) {
		return session.insert("Review.reviewWrite", r_vo) == 1;
	}
	
	//reviewNum 얻기
	public int getReviewNum() {
		return session.selectOne("Review.getReviewNum");
	}
}
