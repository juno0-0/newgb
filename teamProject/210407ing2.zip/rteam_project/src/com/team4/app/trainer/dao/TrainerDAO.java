package com.team4.app.trainer.dao;

import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.team4.app.trainer.vo.TrainerVO;
import com.team4.mybatis.config.SqlMapConfig;
public class TrainerDAO {
	private static final int KEY = 3;
	
	SqlSessionFactory session_f = SqlMapConfig.getSqlMapInstance();
	SqlSession session;
	

public TrainerDAO() {
	session = session_f.openSession(true);
}

	//트레이너 회원가입 
	public boolean join(TrainerVO trainer) {
		
		return session.insert("Trainer.join",trainer)==1;
	}
	
	//암호화
	public String encrypt(String pw) {
		String en_pw="";
		for(int i=0; i<pw.length(); i++) {
			en_pw += (char)(pw.charAt(i)*KEY);
		}
		return en_pw;
	}
	
	//복호화
	public String decrypt(String en_pw) {
		String de_pw="";
		for(int i=0; i<en_pw.length(); i++) {
			de_pw += (char)(en_pw.charAt(i)/KEY);
		}
		return de_pw;
	}
	
	/**
	 * 
	 * @param id
	 * @return
	 * 
	 * true: 중복된 아이디 <br> false: 사용가능한 아이디
	 */
	//아이디검사
		public boolean checkId(String id) {
			
			return (Integer)session.selectOne("Member.checkId",id)==1;
		}
		
		
		public boolean login(String id, String pw) {
			HashMap <String,String>trainer = new HashMap<>();
			trainer.put("id", id);	
			trainer.put("pw", encrypt(pw));
			
			return (Integer)session.selectOne("Member.login",trainer)==1;
		}
	
}
