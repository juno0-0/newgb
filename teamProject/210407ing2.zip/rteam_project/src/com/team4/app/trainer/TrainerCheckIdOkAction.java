package com.team4.app.trainer;

public class TrainerCheckIdOkAction {

}
