package com.team4.app.review;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.trainer.dao.TrainerDAO;
import com.team4.app.trainer.vo.TrainerVO;

public class PropensityResultOkAction implements Action{
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		
		TrainerDAO t_dao = new TrainerDAO();
		ActionForward forward = new ActionForward();
		
		List<TrainerVO> list = (List<TrainerVO>)req.getAttribute("list");
		/* List<String>으로 받아져서 안됨
			if(list == null) {
			List<String> test1 = Arrays.asList(req.getParameterValues("list"));
			for(String str : test1) {
				System.out.println(test1.get(0));
			}
		}*/
		/*System.out.println(list.get(0).getTrainerId());*/
		
		String temp = req.getParameter("page");
		
		int page = temp == null ? 1 : Integer.parseInt(temp);
		
		int boardSize = 5;
		int pageSize = 5;
		int endRow = page * boardSize;
		int startRow = endRow - (boardSize - 1);
		int startPage = ((page - 1) / pageSize) * pageSize + 1;
		int endPage = startPage + (pageSize - 1);
		int totalCnt = list.size();
		int realEndPage = (totalCnt - 1) / pageSize + 1;
		endPage = endPage > realEndPage ? realEndPage : endPage;
		
		/*List<TrainerVO> test = new ArrayList<>();
		
		for(int i=startRow-1; i < endRow; i++) {
			test.add(list.get(i));
		}*/
		
		req.setAttribute("totalCnt", totalCnt);
		req.setAttribute("startPage", startPage);
		req.setAttribute("endPage", endPage);
		req.setAttribute("nowPage", page);
		req.setAttribute("realEndPage", realEndPage);
		req.setAttribute("resultList", list);
		req.setAttribute("trainerCnt", t_dao.trainerCnt());
		//req.setAttribute("test", test);
		
		forward.setRedirect(false);
		forward.setPath("/app/trainer/trainerList.jsp");
		return forward;
	}
}
