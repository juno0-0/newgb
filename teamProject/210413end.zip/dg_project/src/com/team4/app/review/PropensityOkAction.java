package com.team4.app.review;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.review.dao.ReviewDAO;
import com.team4.app.trainer.vo.TrainerVO;

public class PropensityOkAction implements Action{
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		
		ReviewDAO r_dao = new ReviewDAO();
		
		ActionForward forward = new ActionForward();
		
		String[] attentionCheck = new String[9];
		attentionCheck = req.getParameterValues("attentionCheck");
		
		String[] dateCheck = new String[8];
		dateCheck = req.getParameterValues("dateCheck");
		
		String tgCheck = req.getParameter("tgCheck");
		int zipCode = Integer.parseInt(req.getParameter("zipCode"));
		
		List<TrainerVO> list = r_dao.propensity(tgCheck, zipCode, attentionCheck, dateCheck);
		
		req.setAttribute("list", list);
		
		forward.setRedirect(false);
		forward.setPath("/review/PropensityResult.rv");
		
		return forward;
	}
}
