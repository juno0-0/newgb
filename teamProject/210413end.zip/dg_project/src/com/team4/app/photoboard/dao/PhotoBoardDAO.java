package com.team4.app.photoboard.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.team4.app.photoboard.vo.PhotoBoardVO;
import com.team4.mybatis.config.SqlMapConfig;

public class PhotoBoardDAO {

	SqlSessionFactory session_f = SqlMapConfig.getSqlMapInstance();
	SqlSession session;
	

public PhotoBoardDAO() {
	session = session_f.openSession(true);
}

//회원게시판 글작성
	public boolean photoBoardWrite(PhotoBoardVO p_vo) {
		
		
		return session.insert("member.photoBoardWrite",p_vo)==1;
	}
	
//조회수 업데이트
	public boolean updateReadCount(int photoBoardNum) {
		
		return session.update("member.updateReadCount",photoBoardNum)==1;
	}
}
