package com.team4.app.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.fileName.dao.FileNameDAO;
import com.team4.app.fileName.vo.FileNameVO;
import com.team4.app.member.dao.MemberDAO;
import com.team4.app.member.vo.MemberVO;

public class MemberWithdrawalOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		
		ActionForward forward = null;
		MemberDAO m_dao = new MemberDAO();
		MemberVO m_vo = new MemberVO();
		
		FileNameDAO f_dao = new FileNameDAO();
		
		String id = req.getParameter("memberId");
		String pw = req.getParameter("memberPw");
		
		
		
		
		if(m_dao.withdrawal(id, pw)) {
			if(f_dao.deleteUserFile(id)) {
				forward = new ActionForward();
				forward.setRedirect(true);
				forward.setPath(req.getContextPath() + "/app/public/index.jsp");
			}
			
			System.out.println("해당 유저파일 정보삭제");
		}
		
		
		return forward;
	}

}
