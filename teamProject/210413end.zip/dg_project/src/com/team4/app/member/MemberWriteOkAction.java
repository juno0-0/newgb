package com.team4.app.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.photoboard.dao.PhotoBoardDAO;
import com.team4.app.photoboard.vo.PhotoBoardVO;

public class MemberWriteOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		System.out.println("MemberWriteOkAction들어옴");
		ActionForward forward = null;
		
		PhotoBoardVO p_vo = new PhotoBoardVO();
		PhotoBoardDAO p_dao = new PhotoBoardDAO();
		
		
		p_vo.setPhotoBoardTitle(req.getParameter("photoBoardTitle"));
		p_vo.setMemberId(req.getParameter("memberId"));
		p_vo.setPhotoBoardContent(req.getParameter("photoBoardContent"));
		
		if(p_dao.photoBoardWrite(p_vo)) {
			forward = new ActionForward();
			forward.setRedirect(true);
			forward.setPath(req.getContextPath()+"/app/member/memberBoard.jsp");
			System.out.println("photoBoardWrite성공");
		}
		return forward;
	}
}
