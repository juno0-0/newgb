package com.team4.app.trainer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.trainer.dao.TrainerDAO;

public class TrainerLoginOkAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		req.setCharacterEncoding("UTF-8");

		HttpSession session = req.getSession();
		ActionForward forward = new ActionForward();

		TrainerDAO t_dao = new TrainerDAO();

		String id = req.getParameter("Id");
		String pw = req.getParameter("Pw");

		if (t_dao.login(id, pw)) {
			System.out.println("로그인성공");
			session.setAttribute("session_id", id);
			forward.setRedirect(true);
			forward.setPath(req.getContextPath() + "/app/public/index.jsp");
		} else {
			System.out.println("로그인실패");
			forward.setRedirect(false);
			forward.setPath("/trainer/TrainerLogin.tr?login=false;");
		}

		return forward;
	}
}
