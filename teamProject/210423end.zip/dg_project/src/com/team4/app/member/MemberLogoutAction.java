package com.team4.app.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team4.action.Action;
import com.team4.action.ActionForward;

public class MemberLogoutAction implements Action{

		@Override
		public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
			HttpSession session = req.getSession();//세션반환하고
			ActionForward forward = new ActionForward();
			
			
			//존재하는 세션삭제
			session.invalidate();
			
			forward.setRedirect(true);
			forward.setPath(req.getContextPath()+"/index.jsp");
			
			return forward;
		}
}
