package com.team4.app.report.vo;
/*REPORTNUM NUMBER,
REPORTTITLE VARCHAR2(1000),
REPORTID VARCHAR2(500),
REPORTCONTENT VARCHAR2(3000),
UPLOAD DATE DEFAULT SYSDATE,
READCOUNT NUMBER,*/
public class ReportVO {
	private int reportNum;
	private String reportTitle;
	private String reportId;
	private String reportContent;
	private String upload;
	private int readCount;
	
	public ReportVO() {;}

	public final int getReportNum() {
		return reportNum;
	}

	public final void setReportNum(int reportNum) {
		this.reportNum = reportNum;
	}

	public final String getReportId() {
		return reportId;
	}

	public final void setReportId(String reportId) {
		this.reportId = reportId;
	}

	public final String getReportContent() {
		return reportContent;
	}

	public final void setReportContent(String reportContent) {
		this.reportContent = reportContent;
	}

	public final String getUpload() {
		return upload;
	}

	public final void setUploda(String upload) {
		this.upload = upload;
	}

	public final int getReadCount() {
		return readCount;
	}

	public final void setReadCount(int readCount) {
		this.readCount = readCount;
	}


	public final void setUpload(String upload) {
		this.upload = upload;
	}
	
	public final String getReportTitle() {
		return reportTitle;
	}

	public final void setReportTitle(String reportTitle) {
		this.reportTitle = reportTitle;
	}
}
