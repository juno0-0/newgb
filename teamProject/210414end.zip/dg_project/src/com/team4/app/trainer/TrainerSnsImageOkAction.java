package com.team4.app.trainer;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.qna.dao.FilesDAO;
import com.team4.app.trainer.dao.TrainerDAO;

public class TrainerSnsImageOkAction implements Action{
	
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		
		System.out.println("ㅎㅇ1");
		TrainerDAO t_dao=new TrainerDAO();
		String id=req.getParameter("TrainerId");
		System.out.println("ㅎㅇ2");
		FilesDAO f_dao= new FilesDAO();
		System.out.println("ㅎㅇ3");
		 ActionForward forward = null;
		 
		 System.out.println("ㅎㅇ4");
		 
		 System.out.println("ㅎㅇ5");
		 int fileSize = 5 * 1024 * 1024;
		 
		 System.out.println("ㅎㅇ6");
		 MultipartRequest multi = null;
		 System.out.println("ㅎㅇ7");
		 String saveFolder = "C:\\0900_gb_ijh\\jsp\\workspace\\dg_project\\WebContent\\files";
		 
	      multi = new MultipartRequest(req, saveFolder, fileSize, "UTF-8", new DefaultFileRenamePolicy());
		 
		 System.out.println("ㅎㅇ8");
		 System.out.println(t_dao.getSnsNum());
		 System.out.println(multi.getParameter("boardImage"));
		 System.out.println(f_dao.insertFiles(t_dao.getSnsNum(),multi));
		 
			forward= new ActionForward();
			forward.setRedirect(true);
			forward.setPath(req.getContextPath() + "/trainer/sns.tr?TrainerId="+id);

			return forward;
}
}
