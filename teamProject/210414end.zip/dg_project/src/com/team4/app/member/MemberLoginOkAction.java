package com.team4.app.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.member.dao.MemberDAO;
import com.team4.app.trainer.dao.TrainerDAO;

public class MemberLoginOkAction implements Action{
	
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		req.setCharacterEncoding("UTF-8");
		
		HttpSession session = req.getSession();
		ActionForward forward = new ActionForward();
		
		String propensity = req.getParameter("propensity");
		
		//회원 로그인, 트레이너 로그인 분기 처리
		MemberDAO m_dao = new MemberDAO();
		TrainerDAO t_dao = new TrainerDAO();
		
		String id = req.getParameter("Id");
		String pw = req.getParameter("Pw");
		
		if(m_dao.login(id, pw)) {
			System.out.println("회원 로그인 성공");
			session.setAttribute("session_m_id", id);
			forward.setRedirect(true);
			forward.setPath(req.getContextPath()+"/app/public/index.jsp");
		}else if(t_dao.login(id, pw)){
			System.out.println("트레이너 로그인 성공");
			session.setAttribute("session_t_id", id);
			forward.setRedirect(true);
			forward.setPath(req.getContextPath()+"/app/public/index.jsp");
		}else if(!m_dao.login(id, pw)){
			System.out.println("회원 로그인실패");
			forward.setRedirect(false);
			forward.setPath("/member/MemberLogin.me?login=false;");
		}else if(!t_dao.login(id, pw)) {
			System.out.println("트레이너 로그인실패");
			forward.setRedirect(false);
			forward.setPath("/member/MemberLogin.me?login=false;");
		}
		
		//propensity에 false가 들어있을 경우
		if(propensity != null) {
			if(forward.isRedirect()) {
				forward.setPath(req.getContextPath()+"/review/Propensity.rv");
			}
		}
		
		return forward;
	}

}
