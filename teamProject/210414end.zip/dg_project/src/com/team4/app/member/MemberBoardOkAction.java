package com.team4.app.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.photoboard.dao.PhotoBoardDAO;

public class MemberBoardOkAction implements Action {

	
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		
		PhotoBoardDAO p_dao = new PhotoBoardDAO();
		ActionForward forward = new ActionForward();
		String temp = req.getParameter("page");
		
		int page = temp == null? 1: Integer.parseInt(temp);
		
		int boardSize = 10;
		int pageSize = 10;
		
		int endRow = page*boardSize; //한 페이지의 가장 마지막 행 번호 (제일 최신글?)
		
		int startRow = endRow -(boardSize-1);
		
		int startPage = ((page-1)/pageSize)*pageSize+1; //그냥 page하면 되는거 아니야 ? 
		int endPage = startPage +(pageSize-1);	//요청한 페이지에 따라 한리스트에 보이는 마지막 페이지
		
		int totalCnt = p_dao.getBoardCnt();
		int realEndPage = (totalCnt-1)/pageSize +1;	// 절대적인 전체의 마지막 페이지 4/10 +1
		
		endPage = endPage >realEndPage ? realEndPage :endPage; //만약 한줄의 페이지 리스트(1~10)만큼의 게시글도 없을때 endPage를 realPage랑 같게해라
		
		// 이제 위의 벨류를 키 값에 담아서 보내자.
		req.setAttribute("totalCnt", totalCnt);
		req.setAttribute("startPage", startPage);
		req.setAttribute("endPage", endPage);
		req.setAttribute("nowPage", page);
		req.setAttribute("realEndPage", realEndPage);
		req.setAttribute("boardList", p_dao.getBoardList(startRow, endRow));
		
		//setAttribute로 값을 전달하니까 forward로
		forward.setRedirect(false);
		forward.setPath("/app/member/memberBoard.jsp");
		
		return forward;
	}
}
