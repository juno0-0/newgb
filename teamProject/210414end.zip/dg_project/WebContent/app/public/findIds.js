/**
 *아이디찾기
 */

var check = false;



function formSubmit(){
	var form = document.findIdForm;
	   
	   if(!check){
	      alert("다시 확인해주세요.");
	      return false;
	   }
	   form.submit();
}
