package com.team4.app.trainer;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team4.action.ActionForward;
import com.team4.app.member.MemberCheckIdOkAction;

public class TrainerFrontController extends HttpServlet{

	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(req,resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(req,resp);
	}
	
	protected void doProcess(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String requestURI = req.getRequestURI();
		String contextPath = req.getContextPath();;
		String command =requestURI.substring(contextPath.length());
		
		ActionForward forward = null;
		
		if(command.equals("/trainer/TrainerJoinOk.tr")) {
			
			try {
				forward = new TrainerJoinOkAction().execute(req, resp);
			} catch (Exception e) {;}
		}else if(command.equals("/trainer/TrainerJoin.tr")) {
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("/trainer/trainerJoin.jsp");
		}else if{ (command.equals("/trainer/TrainerSms.tr")) {
			try {
			System.out.println("Trainer's Front-Controller");
			forward = new TrainerSmsAction().execute(req, resp);
			} catch (Exception e) {;}
		}else { //요청 URL잘못되서 분기처리 실래할 시 
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("/error/404.jsp");
			
		}
		
		//분기처리 끝나고 일괄처리 
		if(forward != null) {
			if(forward.isRedirect()) {
				
				resp.sendRedirect(forward.getPath());
			}else {
				RequestDispatcher dispatcher = req.getRequestDispatcher(forward.getPath());
				dispatcher.forward(req, resp);
			}
		}
		
	}
}
