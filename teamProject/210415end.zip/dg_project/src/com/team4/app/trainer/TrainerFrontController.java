package com.team4.app.trainer;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team4.action.ActionForward;

public class TrainerFrontController extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doProcess(req, resp);
	}

	protected void doProcess(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String requestURI = req.getRequestURI();
		String contextPath = req.getContextPath();
		
		String command = requestURI.substring(contextPath.length());

		ActionForward forward = null;
		
		

		if (command.equals("/trainer/TrainerJoinOk.tr")) {
			System.out.println("TrainerJoinOk 프론트 컨트롤러");
			try {
				forward = new TrainerJoinOkAction().execute(req, resp);
			} catch (Exception e) {System.out.println(e);}
		} else if (command.equals("/trainer/TrainerCheckIdOk.tr")) {

			System.out.println("TrainerCheckIdOk 프론트컨트롤러");
			try {
				forward = new TrainerCheckIdOkAction().execute(req, resp);
			} catch (Exception e) {
				;
			}
		} else if (command.equals("/trainer/TrainerMypageAccountModify.tr")) {
			
			System.out.println("TrainerMypageAccountModify 프론트컨트롤러");
			try {
				forward = new TrainerMypageAccountModifyOkAction().execute(req, resp);
			} catch (Exception e) {
				;
			}
		} else if (command.equals("/trainer/TrainerMypageDrawal.tr")) {
			
			System.out.println("TrainerMypageDrawal 프론트컨트롤러");
			try {
				forward = new TrainerMypageDrawalOkAction().execute(req, resp);
			} catch (Exception e) {
				;
			}
		} else if (command.equals("/trainer/Tpay.tr")) {
			
			System.out.println("Tpay 프론트컨트롤러");
			try {
				forward = new TrainerMypageTpayViewOkAction().execute(req, resp);
			} catch (Exception e) {
				;
			}
		} else if (command.equals("/trainer/Tdrawal.tr")) {
			
			System.out.println("Tdrawal 프론트컨트롤러");
			try {
				forward = new TrainerMypageDrawalViewOkAction().execute(req, resp);
			} catch (Exception e) {
				;
			}
		} else if (command.equals("/trainer/TpayMentBoard.tr")) {
			
			System.out.println("TpayMentBoard 프론트컨트롤러");
			try {
				forward = new TrainerMypageTpayMentBoardViewOkAction().execute(req, resp);
			} catch (Exception e) {
				;
			}
		} else if (command.equals("/trainer/sns.tr")) {
			
			System.out.println("sns 프론트컨트롤러");
			try {
				forward = new TrainerMypageSnsViewOkAction().execute(req, resp);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
		} else if (command.equals("/trainer/TMypageModify.tr")) {
			
			System.out.println("TMypageModify 프론트컨트롤러");
			try {
				forward = new TrainerMypageMypageModifyViewOkAction().execute(req, resp);
			} catch (Exception e) {
				;
			}
		} else if (command.equals("/trainer/TrainerMypageURLModify.tr")) {
			
			System.out.println("TrainerMypageAccountModify 프론트컨트롤러");
			try {
				forward = new TrainerMypageURLModifyOkAction().execute(req, resp);
			} catch (Exception e) {
				;
			}
		} else if (command.equals("/trainer/TrainerMypageView.tr")) {
			
			System.out.println("TrainerMypageView 프론트컨트롤러");
			try {
				forward = new TrainerMypageViewOkAction().execute(req, resp);
			} catch (Exception e) {
				;
			}

		} else if (command.equals("/trainer/TrainerSms.tr")) {
			try {
				System.out.println("Trainer's TrainerSms Front-Controller");
				forward = new TrainerSmsAction().execute(req, resp);
			} catch (Exception e) {
				;
			}
		} else if (command.equals("/trainer/TrainerSnsImage.tr")) {
			try {
				System.out.println("TrainerSnsImage Front-Controller");
				forward = new TrainerSnsImageOkAction().execute(req, resp);
			} catch (Exception e) {
				System.out.println(e.getMessage());
				
			}
		} else if (command.equals("/trainer/TrainerSnsProfileImage.tr")) {
			try {
				System.out.println("TrainerSnsProfileImage Front-Controller");
				forward = new TrainerSnsProfileImageOkAction().execute(req, resp);
			} catch (Exception e) {
				System.out.println(e.getMessage());
				
			}
		} else if (command.equals("/trainer/TrainerSnsImageDelete.tr")) {
			try {
				System.out.println("TrainerSnsImageDelete Front-Controller");
				forward = new TrainerSnsImageDeleteOkAction().execute(req, resp);
			} catch (Exception e) {
				System.out.println(e.getMessage());
				
			}
		} else if (command.equals("/trainer/pro.tr")) {
			try {
				System.out.println("TrainerMypageSnsProfileViewOkAction Front-Controller");
				forward = new  TrainerMypageSnsProfileViewOkAction().execute(req, resp);
			} catch (Exception e) {
				System.out.println(e.getMessage());
				
			}
		} else { // 요청 URL잘못되서 분기처리 실래할 시
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("/error/404.jsp");

		}

		// 분기처리 끝나고 일괄처리
		if (forward != null) {
			if (forward.isRedirect()) {

				resp.sendRedirect(forward.getPath());
			} else {
				RequestDispatcher dispatcher = req.getRequestDispatcher(forward.getPath());
				dispatcher.forward(req, resp);
			}
		}

	}
}
