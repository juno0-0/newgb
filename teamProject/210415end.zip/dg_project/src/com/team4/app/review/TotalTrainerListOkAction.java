package com.team4.app.review;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.member.dao.MemberDAO;
import com.team4.app.trainer.dao.TrainerDAO;

public class TotalTrainerListOkAction implements Action{
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		
		TrainerDAO t_dao = new TrainerDAO();
		MemberDAO m_dao = new MemberDAO();
		ActionForward forward = new ActionForward();
		
		String temp = req.getParameter("page");
		
		int page = temp == null ? 1 : Integer.parseInt(temp);
		
		int boardSize;
		if(page == 1) {
			boardSize = 2;
		}else {
			boardSize = 5;
		}
		int pageSize = 10;
		int endRow = page * boardSize;
		int startRow = endRow - (boardSize - 1);
		int startPage = ((page - 1) / pageSize) * pageSize + 1;
		int endPage = startPage + (pageSize - 1);
		int totalTrainer = t_dao.trainerCnt();
		int totalMember = m_dao.totalMember();
		int realEndPage = (totalTrainer - 1) / pageSize + 1;
		endPage = endPage > realEndPage ? realEndPage : endPage;
		
		
		req.setAttribute("totalTrainer", totalTrainer);
		req.setAttribute("totalMember", totalMember);
		req.setAttribute("startPage", startPage);
		req.setAttribute("endPage", endPage);
		req.setAttribute("nowPage", page);
		req.setAttribute("realEndPage", realEndPage);
		req.setAttribute("trainerList", t_dao.trainerList(startRow, endRow));
		req.setAttribute("top3", t_dao.top3());
		
		forward.setRedirect(false);
		forward.setPath("/app/trainer/totalTrainerList.jsp");
		
		return forward;
	}
}
