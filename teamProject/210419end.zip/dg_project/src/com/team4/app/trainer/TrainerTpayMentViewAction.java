package com.team4.app.trainer;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.qna.dao.FilesDAO;
import com.team4.app.qna.dao.QnaDAO;
import com.team4.app.qna.vo.FilesVO;
import com.team4.app.qna.vo.QnaVO;
import com.team4.app.qna.vo.QreplyVO;
import com.team4.app.trade.vo.TradeVO;
import com.team4.app.trainer.dao.TrainerDAO;

public class TrainerTpayMentViewAction implements Action{

	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		
		req.setCharacterEncoding("UTF-8");
		
		TrainerDAO t_dao=new TrainerDAO();
		
		
		TradeVO t_vo=null;
		
		
		ActionForward forward =null;
		int tradeNum = Integer.parseInt(req.getParameter("TradeNum"));
		int page = Integer.parseInt(req.getParameter("page"));
		
		t_vo= t_dao.getTradeDetail(tradeNum);
		
		
		if(t_vo != null) {
			req.setAttribute("t_vo", t_vo);
			req.setAttribute("page", page);
			
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("/app/trainer/TpaymentView.jsp");
		}
		return forward;
	}
	
	
}
