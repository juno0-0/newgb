package com.team4.app.qnaboard;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.sun.corba.se.spi.orbutil.fsm.Action;
import com.sun.corba.se.spi.orbutil.fsm.FSM;
import com.sun.corba.se.spi.orbutil.fsm.Input;
import com.team4.action.ActionForward;
import com.team4.app.qna.dao.FilesDAO;
import com.team4.app.qna.dao.QnaDAO;
import com.team4.app.qna.vo.QnaVO;

public class QnABoardWriteOkAction implements com.team4.action.Action {

	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		 QnaVO q_vo = new QnaVO();
		 QnaDAO q_dao = new QnaDAO();
		 
		 q_dao.getAll();
		 
		 FilesDAO f_dao= new FilesDAO();
		 ActionForward forward = null;
		 
			
			int fileSize = 5 * 1024 * 1024; //5M
			
			MultipartRequest multi = null;
			String saveFoleder = "/files";
			ServletContext context = req.getSession().getServletContext();
			String realPath = context.getRealPath(saveFoleder);
			multi = new MultipartRequest(req, realPath, fileSize, "UTF-8", new DefaultFileRenamePolicy());
		 
		 System.out.println("다오들어옴1");
		q_vo.setQnaTitle(multi.getParameter("demo-title"));
		q_vo.setMemberId(multi.getParameter("demo-id"));
		q_vo.setQnaContent(multi.getParameter("demo-textarea"));
		System.out.println(q_vo.getQnaTitle());
		System.out.println(q_vo.getMemberId());
		System.out.println(q_vo.getQnaContent());
		System.out.println("다오들어옴2");
		
		boolean check= q_dao.insertQnaBoard(q_vo);
		System.out.println(check);
		if(check) {
			if(f_dao.insertFiles(q_dao.getBoardNum(), multi))
			System.out.println("다오들어옴3");
				forward= new ActionForward();
				forward.setRedirect(true);
				forward.setPath(req.getContextPath()+"/qnaboard/BoardList.qn");
		}
		return forward;
	}
}
