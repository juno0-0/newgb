package com.team4.app.review;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.member.vo.MemberVO;
import com.team4.app.review.dao.ReviewDAO;

public class MemberChargePointOkAction implements Action{
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		
		MemberVO m_vo = new MemberVO();
		ReviewDAO r_dao = new ReviewDAO();
		
		m_vo.setMemberId(req.getParameter("memberId"));
		m_vo.setMemberPoint(Integer.parseInt(req.getParameter("point")));
		
		r_dao.chargePoint(m_vo);
		
		return null;
	}
}
