package com.team4.app.report;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.team4.action.Action;
import com.team4.action.ActionForward;

public class ReportThumbnailOkAction implements Action{

	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		
		String saveFoleder = "/home/files/temp";
		
		//5MB
		int fileSize = 5 * 1024 * 1024;
		
		MultipartRequest multi = null;
		
		multi = new MultipartRequest(req, saveFoleder, fileSize, "UTF-8", new DefaultFileRenamePolicy());
		
		
		return null;
	}

}
