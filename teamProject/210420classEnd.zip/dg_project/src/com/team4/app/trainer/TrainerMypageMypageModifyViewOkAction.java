package com.team4.app.trainer;

import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.qna.vo.ProFileVO;
import com.team4.app.trainer.dao.TrainerDAO;
import com.team4.app.trainer.vo.TrainerVO;

public class TrainerMypageMypageModifyViewOkAction implements Action {
	
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		req.setCharacterEncoding("UTF-8");
		
		System.out.println("ㅎㅇ1");
		TrainerDAO t_dao = new TrainerDAO();
		ProFileVO p_vo =new ProFileVO();
		TrainerVO t_vo=new TrainerVO();
		
		ActionForward forward = null;
		
		System.out.println("ㅎㅇ2");
		String imagename=req.getParameter("profilename");
		System.out.println("ㅎㅇ3");
		String id=req.getParameter("TrainerId");
		System.out.println(id);
		System.out.println(imagename);
		
		if(imagename!=null) {
			p_vo.setFileName(imagename);
			t_vo.setTrainerProfileImage(imagename);
			System.out.println(t_vo.getTrainerProfileImage());
		}
		
		System.out.println("ㅎㅇ523");
		String profilename=t_dao.getProfile(id);
		
		System.out.println("ㅎㅇ551");
		p_vo.setFileName(profilename);
		t_vo.setTrainerProfileImage(profilename);
		
		System.out.println("getProfileImgname2"+t_vo.getTrainerProfileImage());
		
		System.out.println("ㅎㅇ5");
		t_vo = t_dao.getDetail(id);
		
		System.out.println("ㅎㅇ6");
		req.setAttribute("t_vo",t_vo);
		req.setAttribute("p_vo",p_vo);
		System.out.println("ㅎㅇ7");
		
		
		
			forward = new ActionForward();
			forward.setRedirect(false);
			forward.setPath("/app/trainer/TMypageModify.jsp");

			return forward;
	}

}
