package com.team4.app.member.vo;

public class MemberVO {

}
