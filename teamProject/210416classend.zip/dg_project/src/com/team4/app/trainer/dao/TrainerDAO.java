package com.team4.app.trainer.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Random;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.team4.app.qna.vo.ProFileVO;
import com.team4.app.qna.vo.SnsFileVO;
import com.team4.app.trainer.vo.TrainerVO;
import com.team4.mybatis.config.SqlMapConfig;

public class TrainerDAO {
	private static final int KEY = 3;

	SqlSessionFactory session_f = SqlMapConfig.getSqlMapInstance();
	SqlSession session;

	public TrainerDAO() {
		session = session_f.openSession(true);
	}

	// 트레이너 회원가입
	public boolean join(TrainerVO trainer) {
		trainer.setTrainerPw(encrypt(trainer.getTrainerPw()));
		return session.insert("Trainer.join", trainer) == 1;
	}

	// 암호화
	public String encrypt(String pw) {
		String en_pw = "";
		for (int i = 0; i < pw.length(); i++) {
			en_pw += (char) (pw.charAt(i) * KEY);
		}
		return en_pw;
	}

	// 복호화
	public String decrypt(String en_pw) {
		String de_pw = "";
		for (int i = 0; i < en_pw.length(); i++) {
			de_pw += (char) (en_pw.charAt(i) / KEY);
		}
		return de_pw;
	}

	/**
	 * 
	 * @param id
	 * @return
	 * 
	 * 		true: 중복된 아이디 <br>
	 *         false: 사용가능한 아이디
	 */
	// 아이디검사
	public boolean checkId(String id) {

		return (Integer) session.selectOne("Trainer.checkId", id) == 1;
	}

	public boolean login(String id, String pw) {
		HashMap<String, String> trainer = new HashMap<>();
		trainer.put("id", id);
		trainer.put("pw", encrypt(pw));

		return (Integer) session.selectOne("Trainer.login", trainer) == 1;
	}
	//아이디찾기
		public List<String> findId(String PhoneNum){
			return session.selectList("Trainer.findId",PhoneNum);
			
		}
	//비밀번호찾기
		public List<String> findPw(String id,String PhoneNum){
			HashMap<String,String> trainer=new HashMap<>();
			trainer.put("id", id);
			trainer.put("PhoneNum", PhoneNum);
			return session.selectList("Trainer.findPw",trainer);
					
		}
	//
		public void changePw(String id,String pw) {
		HashMap<String, String> member=new HashMap<>();
		member.put("id", id);
		member.put("pw", encrypt(pw));
		session.update("Trainer.changePw",member);
		
	}		
		

	// 현재 시퀀스 가져오기
	public int getTrainerNum() {
		return (Integer)session.selectOne("Trainer.getTrainerNum");
	}


	public String sms(String mypagePhone) {
		System.out.println("trainer's DAO");
		String num = (new Random().nextInt(9000)+1000)+"";//1000~9999
		
//		String api_key = "NCSJ2DN9KV5RBFBT";
//	    String api_secret = "UPWRB6JLN62M6FX1E9ZO7R1BVX4DKZNO";
//	    Message coolsms = new Message(api_key, api_secret);
//
//	    // 4 params(to, from, type, text) are mandatory. must be filled
//	    HashMap<String, String> params = new HashMap<String, String>();
//	    params.put("to", "01046420130");
//	    params.put("from", mypagePhone);
//	    params.put("type", "SMS");
//	    params.put("text", num);
//	    params.put("app_version", "test app 1.2"); // application name and version
//
//	    try {
//	      JSONObject obj = (JSONObject) coolsms.send(params);
//	      System.out.println(obj.toString());
//	    } catch (CoolsmsException e) {
//	      System.out.println(e.getMessage());
//	      System.out.println(e.getCode());
//	    }
		
	    return num;
	}
	
	//트레이너 총 인원수
	public int trainerCnt() {
		return session.selectOne("Trainer.trainerCnt");
	}
	
	public TrainerVO getDetail(String TrainerId) {
		return session.selectOne("Trainer.getDetail", TrainerId);
	}
	
	public boolean updateAccount(TrainerVO t_vo) {
		return session.update("Trainer.updateAccount",t_vo) == 1;
	}
	public boolean updateURL(TrainerVO t_vo) {
		return session.update("Trainer.updateURL",t_vo) == 1;
	}
	public boolean MypageDrawal(TrainerVO t_vo) {
		return session.delete("Trainer.myPageDrawal",t_vo)==1;
	}
	public int getSnsNum() {
		return session.selectOne("Trainer.getSnsNum");
	}
	public int getProNum() {
		return session.selectOne("Trainer.getProNum");
	}
	
	public List<SnsFileVO> getimageList(String trainerId) {
		return session.selectList("Trainer.imagelistAll",trainerId );
	}
	public String getProfileImage(String imageName) {
		return session.selectOne("Trainer.getProfile",imageName);
	}
	public String getProfile(String trainerId) {
		return session.selectOne("Trainer.getProfileTrainer",trainerId);
	}
	public boolean UpdateProfile(TrainerVO t_vo) {
		return session.update("Trainer.UpdateProfile",t_vo)==1;
	}
	
	//모든 트레이너 랜덤으로 가져오기
	public List<TrainerVO> trainerList(int startRow, int endRow){
		HashMap<String, Integer> map = new HashMap<>();
		map.put("startRow", startRow);
		map.put("endRow", endRow);
		
		return session.selectList("Trainer.trainerList", map);
	}
	
	//TOP3
	public List<TrainerVO> top3(){
		return session.selectList("Trainer.top3");
	}
	
	//뷰만들기
	public void createView() {
		String sql = "CREATE VIEW TRAINER_VIEW AS SELECT ROWNUM R, T.* FROM (SELECT * FROM DG_TRAINER ORDER BY DBMS_RANDOM.VALUE) T";
		HashMap<String, String> map = new HashMap<>();
		map.put("sql", sql);
		session.update("Trainer.createView", map);
	}
	
	public void dropView() {
		String sql = "DROP VIEW TRAINER_VIEW";
		HashMap<String, String> map = new HashMap<>();
		map.put("sql", sql);
		session.update("Trainer.dropView", map);
	}
	

}
