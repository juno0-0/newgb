package com.team4.app.review;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.team4.action.Action;
import com.team4.action.ActionForward;
import com.team4.app.member.dao.MemberDAO;
import com.team4.app.review.vo.PageDTO;
import com.team4.app.trainer.dao.TrainerDAO;
import com.team4.app.trainer.vo.TrainerVO;

public class TotalTrainerListOkAction implements Action{
	@Override
	public ActionForward execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		TrainerDAO t_dao = new TrainerDAO();
		MemberDAO m_dao = new MemberDAO();
		ActionForward forward = new ActionForward();
		
		String temp = req.getParameter("page");
		
		int page = temp == null ? 1 : Integer.parseInt(temp);
		
		PageDTO paging = new PageDTO(page, 5, t_dao.trainerCnt());
		List<TrainerVO> trainers = null;
		HttpSession session = req.getSession();
		if(temp == null) {
			t_dao.dropView();
			t_dao.createView();
		}
		trainers = t_dao.trainerList(paging.getStartRow(), paging.getEndRow());
		System.out.println(trainers.get(0).getTrainerId());
		
		req.setAttribute("totalTrainer", paging.getTotalCnt());
		req.setAttribute("totalMember", m_dao.totalMember());
		req.setAttribute("startPage", paging.getStartPage());
		req.setAttribute("endPage", paging.getEndPage());
		req.setAttribute("nowPage", page);
		req.setAttribute("realEndPage", paging.getRealEndPage());
		req.setAttribute("trainerList", trainers);
		req.setAttribute("top3", t_dao.top3());
		
		forward.setRedirect(false);
		forward.setPath("/app/trainer/totalTrainerList.jsp");
		
		return forward;
	}
}
