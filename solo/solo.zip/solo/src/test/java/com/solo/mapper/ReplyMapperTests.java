package com.solo.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.solo.domain.Criteria;
import com.solo.domain.ReplyVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyMapperTests {
	@Setter(onMethod_ = @Autowired)
	private ReplyMapper mapper;
	
	@Test
	public void testDelete() {
		log.info("DELETE COUNT : "+mapper.delete(1L));
	}
	
//	@Test
//	public void testUpdate() {
//		ReplyVO reply = mapper.read(1L);
//		reply.setReply("내가 왜 이러는지~");
//		log.info("UPDATE COUNT: " +mapper.update(reply));
//	}
	
//	@Test
//	public void testGetListWithPaging() {
//		Criteria cri = new Criteria();
//		mapper.getListWithPaging(cri, 4L).forEach(reply -> log.info(reply));
//	}
	
//	@Test
//	public void testRead() {
//		log.info(mapper.read(1L));
//	}
	
//	@Test
//	public void testInsert() {
//		ReplyVO reply = new ReplyVO();
//		reply.setBno(4L);
//		reply.setReply("흐르지 못하게 또 살짝 웃어~");
//		reply.setId("이지은");
//		log.info("INSERT COUNT : "+mapper.insert(reply));
//	}
	
//	@Test
//	public void test() {
//		log.info(mapper);
//	}
}
