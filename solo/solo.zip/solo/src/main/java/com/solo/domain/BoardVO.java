package com.solo.domain;

import lombok.Data;

@Data
public class BoardVO {
	private Long bno;
	private String id;
	private String title;
	private String content;
	private String regDate;
	private String updateDate;
}
