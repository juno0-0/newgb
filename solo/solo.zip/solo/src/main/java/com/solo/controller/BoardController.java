package com.solo.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.solo.domain.AttachVO;
import com.solo.domain.BoardVO;
import com.solo.domain.Criteria;
import com.solo.domain.PageDTO;
import com.solo.service.BoardService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;
import oracle.net.aso.a;

@Controller
@Log4j
@RequestMapping("/board/")
@AllArgsConstructor
public class BoardController {
	private BoardService service;
	//return을 생략하면 default인 forward가 적용된다. 그래서 void인 것
	
	@GetMapping("/register")
	public void register(@ModelAttribute("cri") Criteria cri) {};
	
	@PostMapping("/register")
	public String register(BoardVO board, RedirectAttributes rttr) {
		
		if(board.getAttachList() != null) {
			board.getAttachList().forEach(log::info);
		}
		
		service.register(board);
		rttr.addFlashAttribute("result", board.getBno());
		return "redirect:/board/list";
	}
	
	@GetMapping("/list")
	public void getList(Criteria cri, Model model) {
		model.addAttribute("list", service.getList(cri));
		model.addAttribute("pageMaker", new PageDTO(cri, service.getTotal(cri)));
	}
	
	@GetMapping({"/get", "/modify"})
	public void get(@RequestParam("bno") Long bno, @ModelAttribute("cri") Criteria cri, Model model) {
		model.addAttribute("board", service.get(bno));
	}
	
	@PostMapping("/modify")
	public String modify(BoardVO board, Criteria cri, RedirectAttributes rttr) {
		if(service.modify(board)) {
			rttr.addFlashAttribute("result", "success");
		}
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		rttr.addAttribute("type", cri.getType());
		rttr.addAttribute("keyword", cri.getKeyword());
		return "redirect:/board/list";
	}
	
	@GetMapping("/remove")
	public String remove(Long bno, Criteria cri, RedirectAttributes rttr) {
		List<AttachVO> attachList = service.getAttachList(bno); 
		if(service.remove(bno)) {
			deleteAllFiles(attachList);
			//deleteAllFiles(service.getAttachList(bno));
			//여기서 만약 이 코드를 먼저 사용했다면 service.remove(bno)를 하였을 때
			//더 이상 bno에 해당하는 글이 없기 때문에 오류가 나서 위에서 미리 담아놓고 사용한 것
			rttr.addFlashAttribute("result", "success");
		}
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		rttr.addAttribute("type", cri.getType());
		rttr.addAttribute("keyword", cri.getKeyword());
		return "redirect:/board/list";
	}
	
	@GetMapping("/getAttachList")
	@ResponseBody
	public ResponseEntity<List<AttachVO>> getAttachList(Long bno) {
		return new ResponseEntity<List<AttachVO>>(service.getAttachList(bno), HttpStatus.OK);
	}
	
	private void deleteAllFiles(List<AttachVO> attachList) {
		if(attachList == null || attachList.size() <= 0) {
			return;
		}
		
		attachList.forEach(attach -> {
			try {
				Path path = Paths.get("C:\\upload\\"+attach.getUploadPath()+"\\"+attach.getUuid()+"_"+attach.getFileName());
				//File객체.delete()와 다른 점은 File객체가 있는지 Path 객체가 있는지의 차이
				Files.delete(path);
				
				if(Files.probeContentType(path).startsWith("image")) {
					Path thumbnail = Paths.get("C:\\upload\\"+attach.getUploadPath()+"\\s_"+attach.getUuid()+"_"+attach.getFileName());
					Files.delete(thumbnail);
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		});
	}
}
