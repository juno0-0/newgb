package com.solo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.solo.domain.Criteria;
import com.solo.domain.ReplyVO;
import com.solo.mapper.ReplyMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class ReplyServiceImple implements ReplyService{
	private ReplyMapper mapper;

	@Override
	public int register(ReplyVO reply) {
		return mapper.insert(reply);
	}

	@Override
	public int modify(ReplyVO reply) {
		return mapper.update(reply);
	}

	@Override
	public int remove(Long rno) {
		return mapper.delete(rno);
	}

	@Override
	public ReplyVO get(Long rno) {
		return mapper.read(rno);
	}

	@Override
	public List<ReplyVO> getList(Criteria cri, Long rno) {
		return mapper.getListWithPaging(cri, rno);
	}
}
