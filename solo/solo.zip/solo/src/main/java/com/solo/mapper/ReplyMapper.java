package com.solo.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.solo.domain.Criteria;
import com.solo.domain.ReplyVO;

public interface ReplyMapper {
	public int insert(ReplyVO reply);
	public int update(ReplyVO reply);
	public int delete(Long rno);
	public ReplyVO read(Long rno);
	public List<ReplyVO> getListWithPaging(@Param("cri") Criteria cri, @Param("bno") Long bno);
	public int getTotal(Long bno);
}
