package com.solo.mapper;

import java.util.List;

import com.solo.domain.BoardVO;
import com.solo.domain.Criteria;

public interface BoardMapper {
	public int insertSelectKey_bno(BoardVO board);
	public List<BoardVO> getListWithPaging(Criteria cri);
	public int update(BoardVO board);
	public int delete(Long bno);
	public BoardVO read(Long bno);
	public int getTotal(Criteria cri);
}
