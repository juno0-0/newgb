package com.solo.service;

import java.util.List;

import com.solo.domain.Criteria;
import com.solo.domain.ReplyVO;

public interface ReplyService {
	public int register(ReplyVO reply);
	public int modify(ReplyVO reply);
	public int remove(Long rno);
	public ReplyVO get(Long rno);
	public List<ReplyVO> getList(Criteria cri, Long bno);
}
