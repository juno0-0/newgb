package com.solo.mapper;

import java.util.List;

import com.solo.domain.AttachVO;

public interface AttachMapper {
	public void insert(AttachVO vo);
	public void delete(String uuid);
	public void deleteAll(Long bno);
	public List<AttachVO> findByBno(Long bno);
}
