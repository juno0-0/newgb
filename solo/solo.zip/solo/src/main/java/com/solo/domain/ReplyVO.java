package com.solo.domain;

import lombok.Data;

@Data
public class ReplyVO {
	Long rno;
	Long bno;
	String reply;
	String id;
	String regDate;
	String updateDate;
}
