package com.solo.domain;

import java.util.List;

import lombok.Data;

@Data
public class AllFileDTO {
	List<AttachVO> succeedList;
	List<AttachVO> failureList;
}
