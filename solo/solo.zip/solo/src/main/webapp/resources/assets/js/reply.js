/**
 * 
 */

var replyService = (function(){
	function add(reply, callback, error){
		$.ajax({
			type: "post",
			url: "/replies/new",
			data: JSON.stringify(reply),
			contentType: "application/json",
			success: function(result){
				if(callback){
					callback(result);
				}
			},
			error: function(xhr, status, err){
				if(error){
					error(err);
				}
			}
		});
	}
	
	function get(rno, callback, error){
		$.get("/replies/"+rno, function(data){
			if(callback){callback(data);}
		}).fail(function(xhr, status, err){
			if(error){error(err);}
		})
	}
	
	function getList(param, callback, error){
		var bno = param.bno;
		var page = param.page || 1;
		$.getJSON("/replies/pages/"+bno+"/"+page+".json", function(data){
			if(callback){callback(data);}
		}).fail(function(xhr, status, err){
			if(error){error(err);}
		})
	}
	
	function remove(rno, callback, error){
		$.ajax({
			type: "delete",
			url: "/replies/"+rno,
			success: function(result){
				if(callback){callback(result);}
			},
			error: function(xhr, status, err){
				if(error){error(err);}
			}
		})
	}
	
	function modify(param, callback, error){
		$.ajax({
			type: "put",
			url: "/replies/"+param.rno,
			data: JSON.stringify(param),
			contentType: "application/json; charset=utf-8",
			success: function(result){
				if(callback){callback(result);}
			},
			error: function(xhr, status, err){
				if(error){error(err);}
				console.log(err);
			}
		})
	}
	
	return {add: add, 
			get: get,
			getList: getList,
			remove: remove,
			modify: modify}
	
})();