package com.solo.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.solo.domain.BoardVO;
import com.solo.domain.Criteria;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardMapperTests {
	@Setter(onMethod_ = @Autowired)
	private BoardMapper mapper;

	@Test
	public void testDelete() {
		log.info("DELETE COUNT : "+mapper.delete(2L));
	}
	
//	@Test
//	public void testUpdate() {
//		BoardVO board = mapper.read(2L);
//		board.setContent("수정테스트");
//		log.info("UPDATE COUNT : "+mapper.update(board));
//	}
	
//	@Test
//	public void testGetTotal() {
//		log.info(mapper.getTotal());
//	}
	
//	@Test
//	public void testGetListWithPaging() {
//		Criteria cri = new Criteria(1, 10);
//		mapper.getListWithPaging(cri).forEach(board -> log.info(board.getBno()));
//	}
	
//	@Test
//	public void testRead() {
//		log.info(mapper.read(2L));
//	}
	
//	@Test
//	public void testInsertSelectKey_bno() {
//		BoardVO board = new BoardVO();
//		board.setId("test");
//		board.setTitle("test");
//		board.setContent("test");
//		log.info("INSERT COUNT : "+mapper.insertSelectKey_bno(board));
//	}
	
//	@Test
//	public void test() {
//		log.info(mapper);
//	}
	
}
