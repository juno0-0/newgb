package com.solo.service;

import java.util.List;

import com.solo.domain.BoardVO;
import com.solo.domain.Criteria;

public interface BoardService {
	public int register(BoardVO board);
	public int remove(Long bno);
	public int modify(BoardVO board);
	public List<BoardVO> getList(Criteria cri);
	public BoardVO get(Long bno);
	public int getTotal();
}
